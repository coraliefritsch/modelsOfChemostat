# -*- coding:Utf-8 -*-
import matplotlib
matplotlib.use('Agg')
import numpy as np
import random as rd
import time
import shutil
import sys
import os
sys.path.append(os.getcwd()+'/source_files')

'''============================================================================
                         Selection of new or old parameters :
============================================================================'''
print"""
Do you want to :
   1 create simulations with a NEW parameters set ?
   2 do simulations with an OLD parameters set ?
   q quit
"""
stop = False
while stop==False:
    action = raw_input("Select an action (1, 2 or q): ")
    if action in ["1", "2", "q", "Q"]:
        stop = True

if action=="Q":
    action="q"
    
if action=="1":
    stop = False
    while stop == False:
        yesno = raw_input("Did you enter the simulation parameters in the file global_parameters.py? (y,n)")
        if yesno=="y" or yesno=='Y':
            stop = True 
        if yesno=="n" or yesno=='N':
            print "Enter the parameters in the file global_parameters.py"
            stop = True
            action="q"

newsimu = False

if action=="1":
    #creation of the new folder
    if os.path.exists('Simulations')==False:
        os.mkdir('Simulations')   
    folder = time.strftime('Simulations/%y%m%d%H%M%S',time.localtime())
    os.mkdir(folder)
    
    "Copy of the parameters file"
    os.mkdir(folder+'/source_files')
    shutil.copy("global_parameters.py", folder+'/source_files/simulationParameters.py')
    shutil.copy("run.py", folder+'/source_files')
    newsimu = True
    
if action=="2":
    #selection of the simulation
    if os.path.exists('Simulations')==False:
        list = []
    else:
        list = os.listdir('Simulations')

    if list == []:
        print "No simulation was realized"
        action="q"
    else:
        list.sort()
        a = []
            
        print "List of the simulations:"
        for i in range(len(list)):
            print i+1, ' ', list[i]
            a.append(str(i+1))
        print "q quit"
        a += 'q'
        a += 'Q'
        
        stop = False
        while stop == False:
            numsimu = raw_input("Enter the simulation number :")
            if numsimu in a:
                stop = True
        if numsimu=="q" or numsimu=='Q':
            action = "q"
        else:
            folder = 'Simulations/'+list[int(numsimu)-1]

if action<>"q":
    sys.path.append(os.getcwd()+'/'+ folder +'/source_files')

'''============================================================================
                         Choice of the action :
============================================================================'''
if action<>"q":
    print """
Possible actions :
   1 Simulations of the growth-fragmentation-death chemostat IBM
   2 Resolution of the growth-fragmentation-death chemostat PDE
   3 Simulations of the birth-death process with Monod kinetic fitted on IBM
   4 Law of the extinction time of IBM simulations
   5 Graphs of existing simulation(s)
   6 ODE with Monod kinetic fitted on IBM (calculed by a least square method)
   q quit
"""

    stop = False
    while stop==False:
        action = raw_input("Select an action (1, 2, 3, 4, 5, 6 or q): ")
        if action in ["1", "2", "3", "4", "5", "6", "q", 'Q']:
            stop = True

if action=="1":
    if newsimu==True:
        #simulation of a new IBM
        import simulationIBM
        simulationIBM.simulation(folder)
    else:
        if os.path.exists(folder+'/IBM')==False:
            nbSimuAdd = int(raw_input("Enter the number of runs:"))
            os.mkdir(folder +'/IBM')
            rd.seed(0)
            np.save(folder+'/IBM/seed.npy', rd.getstate())
        else:
            #Additional runs of an existing IBM simulation
            nbOldSimu = 0
            while os.path.exists(folder+'/IBM/Simulation'+str(nbOldSimu))==True:
                nbOldSimu +=1 
            print nbOldSimu, " simulation(s) of the IBM was already realized."
            nbSimuAdd = int(raw_input("Enter the number of additional runs:"))
        
        import simulationIBMsupp
        simulationIBMsupp.simulation(folder, nbSimuAdd)
    print "simulations are saved in " + folder +  "/IBM"
else:
    if newsimu==True:
        import plot_parameters as sp
        sp.modification_of_the_parametersSimulation_file(folder, 0)
        
if action=="2":
    #resolution of the PDE
    import IDE
    if os.path.exists(folder +'/IDE')==True:
        print "The solution of IDE is already performed"
    else:
        print "The resolution of PDE can take time"
        [substrate_IDE, biomass_IDE, density_IDE ,density_IDE2,
         size_IDE] = IDE.solution_IDE(folder)
        os.mkdir(folder +'/IDE')
        np.save(folder +'/IDE/substrate_IDE.npy', substrate_IDE)
        np.save(folder +'/IDE/biomass_IDE.npy', biomass_IDE)
        np.save(folder +'/IDE/density_IDE.npy', density_IDE)
        np.save(folder +'/IDE/density_IDE2.npy', density_IDE2)
        np.save(folder +'/IDE/size_IDE.npy', size_IDE)
    print "The solution of IDE is saved in " + folder +  "/IDE"
if action=="3":
    #Birth-death process associated to a simulation of IBM
    import simulationBDP
    if os.path.exists(folder +'/IBM')==False:
        print "Simulations of IBM have not been performed"
    else:
        if os.path.exists(folder +'/BDP')==True:
            print "Simulations of the BDP have already be performed"
        else:
            print "Simulation of the birth death process"
            nbSimuBDP = int(raw_input("Enter the number of runs:"))
            simulationBDP.simulationBDP(folder, nbSimuBDP)
        print "simulations are saved in " + folder +  "/BDP"
    
if action=="4":
    #Law of the extinction time
    if os.path.exists(folder +'/IBM')==False:
        print "Simulations of IBM have not been performed"
    else:
        import law_of_extinction_time
        law_of_extinction_time.plot_the_law(folder)

if action=="5":
    #Plot
    import graph
    traceIDE = False
    traceBDP = False
    if os.path.exists(folder +'/IDE'):
        stop = False
        while stop==False:
            ide = raw_input("Do you want to plot the solution of IDE (y,n)? ")
            if ide=='y' or ide=='Y':
                traceIDE = True
                stop = True
            if ide=='n' or ide=='N':
                stop = True
       
    if os.path.exists(folder +'/BDP'):
        stop = False
        while stop==False:
            bdp = raw_input("Do you want the law of the birth-deat process (y,n)? ")
            if bdp=='y' or bdp=='Y':
                traceBDP = True
                stop = True
            if bdp=='n' or bdp=='N':
                stop = True
    if os.path.exists(folder +'/IBM'):
        nbibm = raw_input("How many runs of IBM do you want to plot? (enter 'a' for all)")
    else:
        nbibm = 0
    
    stop = False
    while stop==False:
        lan = raw_input("Which language for the graphs? English (e) or french (f)?")
        if lan=='e' or lan=='E':
            language = 'E'
            stop = True
        if lan=='f' or lan=='F':
            language = 'F'
            stop = True


    import simulationParameters
    T = simulationParameters.T
    delta_t = simulationParameters.save_step_time
    times = np.array([0.0, int(T/(2*delta_t))*delta_t, int(T/delta_t)*delta_t])
    nbHisStep = 20 #20, 50, 100

    print 'Densities will be ploted at times ',  times,
    print ' (3 times between 0 and', T, ')'
    print 'with ' , nbHisStep, ' mass intervals for histograms'
    stop = False
    while stop==False:
        changePara = raw_input("Do you want to change these parameters (y,n)? ")
        if changePara=='y' or changePara=='Y':
            changePara=='y'
            stop = True
        if changePara=='n' or changePara=='N':
            stop = True
    
    if changePara=='y':
        nbtimes = int(raw_input("How many regulary spaced density times : "))
        nbHisStep= int(raw_input("Numbers of mass intervals: "))
        times = np.linspace(0,T,nbtimes)
        for i in range(nbtimes):
            times[i] = int(i*T/((nbtimes-1)*delta_t))*delta_t
    graph.plot_curves(folder, nbibm, traceIDE,language, nbHisStep, times,
                      traceBDP)
    
if action=="6":
    #ODE associated to a simulation of IBM
    import ODE
    stop = False
    while stop==False:
        lan = raw_input("Which language for the graphs? English (e) or french (f)?")
        if lan=='e' or lan=='E':
            language = 'E'
            stop = True
        if lan=='f' or lan=='F':
            language = 'F'
            stop = True
    ODE.ODE(folder, language)
