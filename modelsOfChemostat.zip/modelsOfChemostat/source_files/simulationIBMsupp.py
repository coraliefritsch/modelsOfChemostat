# -*- coding:Utf-8 -*-
'Additionnal simulations of the growth-fragmentation-death chemostat IBM'
import numpy as np
import random as rd
import os
import sys
import shutil

def simulation(folder, nbSimuSupp):
    'run of the IBMs'
    sys.path.append(os.getcwd()+'/'+ folder +'/source_files')
    import simulationParameters as parameters
    
    #copy of the Python files    
    shutil.copy("source_files/simulationIBM.py", folder+'/source_files')
    shutil.copy("source_files/class_universe.py", folder+'/source_files')
    shutil.copy("source_files/plot_parameters.py", folder+'/source_files')
    shutil.copy("source_files/class_individual.py", folder+'/source_files')
    shutil.copy("source_files/class_population.py", folder+'/source_files')
    shutil.copy("source_files/class_efficiency.py", folder+'/source_files')
    
    sys.path.append(os.getcwd()+'/'+folder+'/source_files')
    import class_universe as universe
    import plot_parameters as sp
    
    oldNbSimu = parameters.Nbsimu
    
    #modification of the number of simulations in the parameters file
    sp.modification_of_the_parametersSimulation_file(folder,
                                                     oldNbSimu
                                                     +nbSimuSupp)

    #Initialization of the random number generator
    rd.setstate(np.load(folder+'/IBM/seed.npy'.format(oldNbSimu-1)))
    
    for k in xrange(nbSimuSupp):
        #Creation of a folder to save data of the k-th simulation
        os.mkdir(folder+'/IBM/Simulation{0}'.format(oldNbSimu+k))
        sys.stdout.write("\rSimulation {0} / {1}".format(k+1, nbSimuSupp))
        sys.stdout.flush()
        
        #Initialization of the chemostat
        chemostat = universe.Chemostat()
        
        #Gillespie Algorithm
        chemostat.gillespie(parameters.T,
                            parameters.save_step_time,
                            parameters.eulerTime,
                            folder+'/IBM/Simulation{0}'.format(oldNbSimu+k))
        np.save(folder+'/IBM/Simulation{0}/seed.npy'.format(oldNbSimu+k),
                rd.getstate())
        np.save(folder+'/IBM/seed.npy'.format(oldNbSimu+k), rd.getstate())

    print ''
