# -*- coding: utf-8 -*-
import numpy as np
import sys
import os
import shutil

def solution_IDE(folderName):
    '''compute the solution of the growth-fragmentation-death chemostat model
    with parameters of the folder folderName and return
    [substrate, biomass, density, densitybis, pop_size] with
       substrate : the time evolution of the substrate concentration
       biomass : the time evolution of the biomass concentration
       density : the time evolution of the mass density of individuals
       densitybis : normalized time evolution density
       pop_size : the time evolution of the number of individuals'''
    
    shutil.copy("source_files/IDE.py", folderName+'/source_files')
    sys.path.append(os.getcwd()+'/'+folderName+'/source_files')
    import simulationParameters

    #recovery of the parameters
    T = np.float(simulationParameters.T)
    saveTime = np.float(simulationParameters.save_step_time)
    maxMass = np.float(simulationParameters.M)
    S0 = np.float(simulationParameters.S_0)
    Sin = np.float(simulationParameters.S_in)
    k = np.float(simulationParameters.k)
    D = np.float(simulationParameters.D)
    V = np.float(simulationParameters.V)
    n0 = simulationParameters.n0
    massStep = np.float(simulationParameters.massStep)
    eulerTime = np.float(simulationParameters.eulerTime)
    
    NbEulerStep = int(T/eulerTime+1)
    NbMasses = int(maxMass/massStep)
    NbSaveTime = int(T/saveTime)
    k_V = k/V

    #preliminary computations
    x=np.linspace(0, maxMass, NbMasses+1)
    'computation of the division kernel matrix q=(q(x/z))_{x,z}'
    A=np.ones((NbMasses+1,NbMasses+1))*x
    B=A.T*1
    A=A.T
    A[0]=1
    A=A.T
    q=B/A
    q=q.T
    q[0]=0
    q=q.T
    q = simulationParameters.divisionKernel(q)
    'computation of the matrix divisionRate(z)/z*q(x/z)'
    z=np.linspace(0, maxMass, NbMasses+1)
    z[0] = 1
    matQ = q/z
    '''growth speed and its derivative : the growth speed can not be derivable
     in 0, but if the population is 0 in 0, we can impose that
     dcroissance[0]=0'''
    growthSpeed = simulationParameters.g(x)
    diffGrowthSpeed = simulationParameters.diff_of_g(x)
        
    'allocation of memory'
    substrate = np.zeros(NbSaveTime+1)
    biomass = np.zeros(NbSaveTime+1)
    density = np.zeros((NbSaveTime+1, NbMasses+1))
    densitybis = np.zeros((NbSaveTime+1, NbMasses+1))
    pop_size = np.zeros(NbSaveTime+1)
    dp = np.zeros(NbMasses+1)        #for the derivative of p
   
    'Initialisation'
    p = simulationParameters.initialDensity(x)
    p = p*n0/(np.sum(p)*massStep)
    biomass[0] = massStep * np.dot(x,p)/V
    substrate[0] = S0
    S = S0
    density[0] = p/n0
    densitybis[0] = p
    pop_size[0] = n0
    
    'preliminary computations'
    massStep_inv=1/massStep
    massStep_times_g = massStep*growthSpeed
    lambdax = simulationParameters.divisionRate(x)
    matQ_lambdax = matQ*lambdax

    'explicit numerical scheme'
    j=1
    for i in range(NbEulerStep):
        alpha_S = simulationParameters.mu(S)
        integ2 = np.dot(massStep_times_g,p)       
        S += eulerTime*(D*(Sin-S)-k_V*alpha_S*integ2)   
        integ = massStep*np.dot(matQ_lambdax,p) #long calculus
        dp[1:] = massStep_inv*(p[1:]-p[:-1])
        p += eulerTime*(-alpha_S* (diffGrowthSpeed*p + growthSpeed*dp)
                      -(lambdax+D)*p+2*integ)    
                
        if np.abs(i*eulerTime-j*saveTime)<eulerTime/2:
            substrate[j] = S
            biomass[j] = massStep*np.dot(x,p)/V
            density[j] = massStep_inv*p/np.sum(p)
            densitybis[j] = p
            pop_size[j] = massStep * np.sum(p)
   
            if j==int(NbSaveTime/4):
                print "    25% performed"
            else:
                if j==int(NbSaveTime/2):
                    print "    50% performed"
                else:
                    if j==int(NbSaveTime*3/4):
                        print "    75% performed"
            j+=1
    print "    100% performed"
    return [substrate, biomass, density, densitybis, pop_size]
