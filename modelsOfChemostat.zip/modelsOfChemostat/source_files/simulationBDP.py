# -*- coding:Utf-8 -*-
import numpy as np
import random as rd
import time
import os
import sys
import shutil
import xml.dom.minidom
import leastsquares as MC
import xml.etree.ElementTree as ET
import meanVariance as MV

def simulationBDP(folder, NbsimuBDP):
    """
Simulate NbsimuBDP of the Crump-Young model (system of a non-homogeneous 
birth-death process for the population and an ODE for the substrate dynamics).
The birth rate is a Monod kinetics with parameters of the Monod kinetic fitted 
by a least squares method on the IBM simulations of the simulation `folder'. 
The parameters are saved in a xml file.
"""
    #recovery of the parameters
    shutil.copy("source_files/simulationBDP.py", folder+'/source_files')
    shutil.copy("source_files/class_universe_BDP.py", folder+'/source_files')
    shutil.copy("source_files/meanVariance.py", folder+'/source_files')
    sys.path.append(os.getcwd()+'/'+folder+'/source_files')
    import simulationParameters as parameters
    import class_universe_BDP

    #means and variances of the IBM simulations
    [NbSurvPop, meanMass, meanSubstrate, varMass, varSubstrate, meanSizePop,
     meanMass_non_extinct, meanSubstrate_non_extinct, varMass_non_extinct,
     varSubstrate_non_extinct] = MV.mean_var_IBM(folder, parameters.Nbsimu)

    X_0 = meanMass[0]
    S_0 = meanSubstrate[0]

    #parameters of the Monod kinetic fitted by a least squares method on the IBM
    #simulations
    mumax_min = 0.01
    mumax_max = 20.0
    Kmin = 0.1
    Kmax = 200.0
    
    t = np.arange(0, parameters.T+parameters.save_step_time/2,
                  parameters.save_step_time)

    [mumax, Ks] = MC.optimal_parameters(mumax_min, mumax_max, Kmin, Kmax, S_0,
                                        X_0, t, meanMass, meanSubstrate,
                                        parameters.D, parameters.S_in,
                                        parameters.k, None, None, varMass,
                                        varSubstrate)
 
    if meanSizePop[-1]==0:
        #index of the last time with survival population(s)
        ind = np.size(meanSizePop[meanSizePop<>0])-1 
        individualMass = meanMass[ind]*parameters.V / meanSizePop[int(ind/2)]
    else:   
        individualMass = meanMass[-1]*parameters.V / meanSizePop[-1]
    n0 = int(np.rint(X_0*parameters.V/individualMass))

    os.mkdir(folder+'/BDP')
    
    #save the BDP parameters in a xml file
    ETBDP = ET.Element('BDP')
    ETmumax = ET.SubElement(ETBDP, 'mumax')
    ETmumax.text = str(mumax)
    ETKs = ET.SubElement(ETBDP, 'Ks')
    ETKs.text = str(Ks)
    ETn0 = ET.SubElement(ETBDP, 'n0')
    ETn0.text = str(n0)
    ETmass = ET.SubElement(ETBDP, 'Individualmass')
    ETmass.text = str(individualMass)
    tree = ET.ElementTree(ETBDP)
    tree.write(folder+'/BDP' + '/parameters.xml')

    #Initialization of the random number generator
    rd.seed(0)
    np.random.seed(0)
    for k in xrange(NbsimuBDP):
        #Creation of a folder to save data of the k-th simulation
        os.mkdir(folder+'/BDP/Simulation{0}'.format(k))
        sys.stdout.write("\rSimulation {0} / {1}".format(k+1,NbsimuBDP))
        sys.stdout.flush()
        
        #Initialization of the chemostat
        chemostat = class_universe_BDP.ChemostatBDP(individualMass)
        
        #Gillespie Algorithm
        chemostat.gillespie(parameters.T,
                            parameters.save_step_time,
                            parameters.eulerTime,
                            folder+'/BDP/Simulation{0}'.format(k),
                            mumax, Ks)
        np.save(folder+'/BDP/Simulation{0}/seed.npy'.format(k), rd.getstate())

    print ''
