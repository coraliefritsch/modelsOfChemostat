# -*- coding: utf-8 -*-
import pylab as pl
import numpy as np
import time
import simulationParameters as parameters

def plot_curve_of_the_division_rate(nameFolder):
    """Plot the curve of the division rate of the population. The plot is saved
     in the folder nameFolder."""
    x = np.linspace(0, parameters.M, 1001)
    l = parameters.divisionRate(x)
    pl.clf()
    pl.plot(x, l)
    pl.xlabel('mass')
    pl.ylabel('division rate')
    pl.title('Division Rate of the population')
    pl.savefig(nameFolder + '/division_rate.pdf')
    pl.close()

def plot_curve_of_the_growth_speed(dossier):
    '''Plot the curve of the growth speed of the population for the initial
        concentration of substrate. The plot is saved in the folder
        nameFolder.'''
    x = np.linspace(0, parameters.M, 1001)
    g = parameters.g(x)
    pl.clf()
    pl.plot(x, parameters.mu(parameters.S_0)*g)
    pl.xlabel('mass')
    pl.ylabel('growth speed')
    pl.title('Growth speed of the population')
    pl.savefig(dossier + '/growth_speed.pdf')
    pl.close()

def plot_curve_of_the_division_kernel(dossier):
    """Plot the division kernel of the population. The plot is saved in the
    folder nameFolder."""
    y = np.linspace(0, 1, 101)
    K = parameters.divisionKernel(y)
    pl.clf()
    pl.plot(y, K)
    pl.xlabel('proportion')
    pl.ylabel('density')
    pl.title('Division kernel')
    pl.savefig(dossier + '/division_kernel.pdf')
    pl.close()

def modification_of_the_parametersSimulation_file(dossier, nbsimu):
    '''modify the number of simulations in the file simulationParameters.py'''
    f = open(dossier+'/source_files/simulationParameters.py', 'r')
    lignes = f.readlines()
    for i in range(len(lignes)):
        if 'Nbsimu=' in lignes[i] or 'Nbsimu = ' in lignes[i]:
            lignes[i] = 'Nbsimu = '+ str(nbsimu)+ ' \n'
    f.close()

    f = open(dossier+'/source_files/simulationParameters.py', 'w')
    for i in range(len(lignes)):
        f.write(lignes[i])
    f.close()

