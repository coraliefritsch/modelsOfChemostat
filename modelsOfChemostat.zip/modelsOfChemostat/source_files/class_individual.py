# -*- coding: utf-8 -*-
import numpy as np
import random as rd
import simulationParameters as simupara

class Individual(object):
    'abstract class'
    def mass(self):
        '''return the mass of the individual'''
    
    def birthDate(self):
        '''return the birth date of the individual'''
    
    def changeMass(self):
        '''change the mass of the individual'''
    
    def changeBirthDate(self):
        "change the birth date of the individual"
    
    def divisionRate(self,p):
        """return the division rate of an individual of mass x"""
        return simupara.divisionRate(self.mass())
    
    def massAfterDivision(self):
        "return the mass of one of the two individuals after a division"
    
    
class BasicIndividual(Individual):
    def __init__(self,m, date):
        self.__mass = m
        self.__birthDate = date
        
    def mass(self):
        return self.__mass    
        

class PointerIndividual(Individual):
    '''The class PointerIndividual inhertit the methods of the abstract class
        Individual'''
    def __init__(self,massTab, date, index):
        '''The mass of one individual is the positition index of the table 
        massTab. The birth date of the individual is date'''
        self.__massTab = massTab  
        self.__birthDate = date
        self.__index = index
        
    def mass(self):
        '''return the mass of the individual'''
        return self.__massTab[self.__index]
    
    def birthDate(self):
        '''return the birth date of the individual'''
        return self.__birthDate
    
    def index(self):
        '''return the index of the individual'''
        return self.__index
    
    def changeMass(self,m):
        '''change the mass of the individual : the new mass is m'''
        self.__massTab[self.__index] = m
        
    def changeBirthDate(self,newdate):
        '''change the birth date of the individual : the new date is newdate'''
        self.__birthDate = newdate
        
    def changeIndex(self,index):
        '''change the index of the individual : the new index is index'''
        self.__index = index
    
    def massAfterDivision(self):
        '''return the mass of one of the two individuals after a division'''
        return simupara.masse_after_division(self.__massTab[self.__index])
       
    def listeOfIndividuals(self,n,index):
        '''return a list of n individuals self with the index which is the 
        index of the list+ index'''
        y = [self]*n
        for i in xrange(n):
            y[i].__index = index+i
        return y

    def changeAdressMassTab(self,newTab):
        '''change the tab of masses of individuals : the new tab is newTab'''
        self.__massTab = newTab
