# -*- coding: utf-8 -*-
import pylab as pl
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.collections import PolyCollection
import os

label_size = 22    #size of the font of labels
legendsize = 22    #size of the font of legends
tickssize = 18     #size of the font of ticks

def number_of_individuals(folder, Nsimu, t0, T, steptime, IDE=False, 
                          lang = 'F', scale = 0, BDP=False):
    """
Plot and save in the folder the time evolution curve of the number of
individuals in the population of
    - the IBM runs
    - the mean of IBM runs
    - the solution of IDE if IDE=True
    - the BPD runs if BPD=True
===========  ==================================================================
parameters            
===========  ==================================================================
folder       folder of the simulation
Nsimu        number of simulation of IBM to plot
t0		     start time for the plot
T            maximal time of the plot
steptime     step of time of data saves
IDE          True to plot the solution of IDE, False if not
lang         language for the legends ('F' = french, otherwise = english)
scale        "log" to have a logarithmic scale for the plot
BPD          True to plot the runs of BDP, False if not
===========  ==================================================================
"""
    pl.rcParams['legend.loc'] = 'best'  
    t = np.arange(t0,T+steptime/2,steptime)    
    
    N = int(T/steptime)+1
    n = int(t0/steptime)
    
    pl.clf()
    if lang=='F':
        pl.xlabel('temps (h)', fontsize=label_size)
        pl.ylabel("nombre d'individus", fontsize=label_size)
        legend1 = 'moyenne des IBM'
        legend2 = 'moyenne | non lessivage'
        legend3 = "solution de l'EID"
        legend4 = "IBM"
        legend5 = "PNM"
    else:
        pl.xlabel('time (h)', fontsize=label_size)
        pl.ylabel('number of individuals', fontsize=label_size)
        legend1 = 'mean of IBM'
        legend2 = 'mean | non-washout'
        legend3 = 'IDE'
        legend4 = "IBM"
        legend5 = "BDP"
    
    mean = np.zeros(np.size(t))
    mean_non_ext = np.zeros(np.size(t)) #mean given the non extinction
    Nsimu_non_ext = 0
    for i in xrange(Nsimu-1):
        size = np.load(folder+'/IBM/Simulation{0}/Pop_size.npy'.format(i))[n:N]
        if size[-1]<>0:
            Nsimu_non_ext += 1
            mean_non_ext += size
        pl.plot(t,size, color='b', alpha=0.3)
        mean += size
    if Nsimu<>0:
        size=np.load(folder+'/IBM/Simulation{0}/Pop_size.npy'.format(Nsimu-1))
        if size[-1]<>0:
            Nsimu_non_ext += 1
            mean_non_ext += size
        pl.plot(t, size, color='b', alpha=0.3, label=legend4)
        mean += size

    if BDP==True:
        nbBDP = 0
        stop = False
        while stop==False:
            if os.path.exists(folder+'/BDP/Simulation{0}'.format(nbBDP)):
                nbBDP += 1
            else:
                stop = True
        for i in xrange(nbBDP-1):
            pl.plot(t,
                    np.load(folder + 
                         '/BDP/Simulation{0}/Pop_size_BDP.npy'.format(i))[n:N],
                     color='m', alpha=0.3)
        if nbBDP<>0:
            pl.plot(t,
                    np.load(folder +
                   '/BDP/Simulation{0}/Pop_size_BDP.npy'.format(nbBDP-1))[n:N],
                     color='m', alpha=0.3, label=legend5)
        titleBDP = 'BDP'
    else:
        titleBDP = ''

    if IDE==True:
        pl.plot(t, np.load(folder+'/IDE/size_IDE.npy')[n:N], color='r',
                        label=legend3, linewidth=2.5)

    if Nsimu<>0:
        mean /= Nsimu
        if Nsimu_non_ext<>0:
            mean_non_ext /= Nsimu_non_ext
            if (mean<>mean_non_ext).any() :
                pl.plot(t,mean, '--', color=(0,1,0), label=legend1,
                        linewidth=2.5)
                pl.plot(t,mean_non_ext,'--', color=(0,1,0), 
                    label=legend2, linewidth = 1)
            else:
                pl.plot(t,mean, '--', color=(0,1,0), label=legend1,
                        linewidth=2.5)
        else:
            pl.plot(t,mean, '--', color=(0,1,0), label=legend1, linewidth=2.5)

    pl.legend(prop={'size':legendsize})
    pl.tick_params(axis='both', labelsize=tickssize)
    pl.tick_params(axis='y', labelsize=15)

    if scale=='log':
        pl.yscale('log')
    if lang=='F':
        pl.savefig(folder+'/taille' + titleBDP + '.pdf')
        print "The graph of the number of individual is saved in "
        print "   " + folder+'/taille' + titleBDP + '.pdf'
    else:
        pl.savefig(folder+'/size' + titleBDP + '.pdf')
        print "The graph of the number of individual is saved in "
        print "   " + folder+'/size' + titleBDP + '.pdf'

def biomass(folder,Nsimu,T,steptime,V,IDE, lang='F', BDP=False):
    """
Plot and save in the folder the time evolution curve of the biomass
concentration of
   - the IBM runs
   - the mean of IBM runs
   - the solution of IDE if IDE=True
   - the BPD runs if BPD=True
===========  ==================================================================
parameters            
===========  ==================================================================
folder       folder of the simulation
Nsimu        number of simulation of IBM to plot 
T            maximal time of the plot
steptime     step of time of data saves
V  		     the volume of the chemostat
IDE          True to plot the solution of IDE, False if not
lang         language for the legends ('F' = french, otherwise = english)
BPD          True to plot the runs of BDP, False if not
===========  ==================================================================
"""
    t = np.arange(0,T+steptime/2,steptime)
    pl.rcParams['legend.loc'] = 'best'
    N = int(T/steptime)+1
    
    pl.clf()
    if lang=='F':
        pl.xlabel('temps (h)', fontsize=label_size)
        pl.ylabel('concentration biomasse (mg/l)', fontsize=label_size)
        legend1 = 'moyenne des IBM'
        legend2 = 'moyenne | non lessivage'
        legend3 = "solution de l'EID"
        legend4 = "IBM"
        legend5 = "PNM"
    else:
        pl.xlabel('time (h)', fontsize=label_size)
        pl.ylabel("biomass concentration (mg/l)", fontsize=label_size)
        legend1 = 'mean of IBM'
        legend2 = 'mean | non-washout'
        legend3 = "IDE"
        legend4 = "IBM"
        legend5 = "BDP"
    
    mean = np.zeros(np.size(t))
    mean_non_ext = np.zeros(np.size(t))
    Nsimu_non_ext = 0
    for i in xrange(Nsimu-1):
        biomass = np.load(folder+'/IBM/Simulation{0}/Mass.npy'.format(i))[:N]
        if biomass[-1]<>0:
            Nsimu_non_ext += 1
            mean_non_ext += biomass/V
        pl.plot(t,biomass/V, color='b', alpha=0.3)
        mean += biomass/V
    if Nsimu<>0:
        biomass = np.load(folder + 
                          '/IBM/Simulation{0}/Mass.npy'.format(Nsimu-1))[:N]
        if biomass[-1]<>0:
            Nsimu_non_ext += 1
            mean_non_ext += biomass/V
        pl.plot(t,biomass/V, color='b', alpha=0.3, label = legend4)
        mean += biomass/V
    
    if BDP==True:
        nbBDP = 0
        stop = False
        while stop==False:
            if os.path.exists(folder+'/BDP/Simulation{0}'.format(nbBDP)):
                nbBDP += 1
            else:
                stop = True
        for i in xrange(nbBDP-1):
            pl.plot(t,
                    np.load(folder+
                            '/BDP/Simulation{0}/Mass_BDP.npy'.format(i))[:N]/V,
                     color='m', alpha=0.3)
        if nbBDP<>0:
            pl.plot(t,
                    np.load(folder+
                      '/BDP/Simulation{0}/Mass_BDP.npy'.format(nbBDP-1))[:N]/V,
                     color='m', alpha=0.3, label=legend5)
        titleBDP = 'BDP'
    else:
        titleBDP = ''

    if IDE==True:
        pl.plot(t, np.load(folder+'/IDE/biomass_IDE.npy')[:N], color='r',
                label=legend3, linewidth=2.5)

    if Nsimu<>0:
        mean /= Nsimu
        if Nsimu_non_ext<>0: 
            mean_non_ext /= Nsimu_non_ext
            if (mean<>mean_non_ext).any() :
                pl.plot(t,mean, '--', color=(0,1,0), 
                        label=legend1, linewidth=2.5)
                pl.plot(t,mean_non_ext, color=(0,1,0), 
                        label=legend2, linewidth = 1)
            else:
                pl.plot(t,mean, '--', color=(0,1,0), label=legend1,
                        linewidth=2.5)
        else:
            pl.plot(t,mean, '--', color=(0,1,0), label=legend1, linewidth=2.5)
        
        
    pl.legend(prop={'size':legendsize})
    pl.tick_params(axis='both', labelsize=tickssize)
    if lang=='F':
        pl.savefig(folder+'/biomasse' + titleBDP + '.pdf')
        print "The graph of the biomass evolution is saved in "
        print "   " + folder+'/biomasse' + titleBDP + '.pdf'
    else:
        pl.savefig(folder+'/biomass' + titleBDP + '.pdf')
        print "The graph of the biomass evolution is saved in "
        print "   " + folder+'/biomass' + titleBDP + '.pdf'
    
def substrate(folder,Nsimu,T,steptime,IDE, lang='F', BDP=False):
    """
Plot and save in the folder the time evolution curve of substrate
concentration of
    - the IBM runs
    - the mean of IBM runs
    - the solution of IDE if IDE=True
    - the BPD runs if BPD=True
===========  ==================================================================
parameters            
===========  ==================================================================
folder       folder of the simulation
Nsimu        number of simulation of IBM to plot 
T            maximal time of the plot
steptime     step of time of data saves
IDE          True to plot the solution of IDE, False if not
lang         language for the legends ('F' = french, otherwise = english)
BPD          True to plot the runs of BDP, False if not
===========  ==================================================================
"""

    t = np.arange(0,T+steptime/2,steptime)
    N = int(T/steptime)+1
    
    pl.clf()
    if lang=='F':
        pl.xlabel('temps (h)', fontsize=label_size)
        pl.ylabel('concentration substrat (mg/l)', fontsize=label_size)
        legend1 = 'moyenne des IBM'
        legend3 = "solution de l'EID"
        legend4 = "IBM"
        legend5 = "PNM"
    else:
        pl.xlabel('time (h)', fontsize=label_size)  
        pl.ylabel('substrate concentration (mg/l)', fontsize=label_size)
        legend1 = 'mean of IBM'
        legend3 = "IDE" 
        legend4 = "IBM"
        legend5 = "PNM"

    mean = np.zeros(np.size(t))
    for i in xrange(Nsimu-1):
        subtrate = np.load(folder + 
                           '/IBM/Simulation{0}/Substrate.npy'.format(i))[:N]
        pl.plot(t,subtrate, color='b', alpha=0.3)
        mean += subtrate
    if Nsimu<>0:
        subtrate = np.load(folder + 
                        '/IBM/Simulation{0}/Substrate.npy'.format(Nsimu-1))[:N]
        pl.plot(t,subtrate, color='b', alpha=0.3, label=legend4)
        mean += subtrate

    if BDP==True:
        nbBDP= 0
        stop = False
        while stop==False:
            if os.path.exists(folder+'/BDP/Simulation{0}'.format(nbBDP)):
                nbBDP += 1
            else:
                stop = True
        for i in xrange(nbBDP-1):
            pl.plot(t,np.load(folder + 
                        '/BDP/Simulation{0}/Substrate_BDP.npy'.format(i))[:N], 
                     color='m', alpha=0.3)
        if nbBDP<>0:
            pl.plot(t,np.load(folder + 
                  '/BDP/Simulation{0}/Substrate_BDP.npy'.format(nbBDP-1))[:N], 
                     color='m', alpha=0.3, label=legend5)
  
        titleBDP = 'BDP'
    else:
        titleBDP = ''

    if IDE==True:
        pl.plot(t, np.load(folder+'/IDE/substrate_IDE.npy')[:N], color='r',
                label=legend3, linewidth=2.5)

    if Nsimu<>0:
        mean /= Nsimu
        pl.plot(t,mean, '--', color=(0,1,0), label=legend1, linewidth=2.5)
    pl.legend(prop={'size':legendsize})
    pl.tick_params(axis='both', labelsize=tickssize)

    if lang=='F':
        pl.savefig(folder+'/substrat' + titleBDP + '.pdf')
        print "The graph of the substrate evolution is saved in "
        print "   " + folder+'/substrat' + titleBDP + '.pdf'
    else:
        pl.savefig(folder+'/substrate' + titleBDP + '.pdf')
        print "The graph of the substrate evolution is saved in "
        print "   " + folder+'/substrate' + titleBDP + '.pdf'
        

def phase_portrait(folder, Nsimu, T, steptime, V, IDE, lang='F'):
    """
Plot and save in the folder the time evolution curve of the number of 
individuals in the population of
    - the IBM runs
    - the mean of IBM runs
    - the solution of IDE if IDE=True
===========  ==================================================================
parameters            
===========  ==================================================================
folder       folder of the simulation
Nsimu        number of simulation of IBM to plot 
T            maximal time of the plot
steptime     step of time of data saves
V		     the volume of the chemostat
IDE          True to plot the solution of IDE, False if not
lang         language for the legends ('F' = french, otherwise = english)
===========  ==================================================================
"""
    N = int(T/steptime)+1
    
    pl.clf()
    if lang=='F':
        pl.xlabel('concentration substrat (mg/l)', fontsize=label_size)
        pl.ylabel('concentration biomasse (mg/l)', fontsize=label_size)
        legend1 = 'moyenne de IBM'
        legend3 = "solution de l'EID"
        legend4 = "IBM"
    else:
        pl.xlabel('substrate concentration (mg/l)', fontsize=label_size)
        pl.ylabel('biomass concentration (mg/l)', fontsize=label_size)
        legend1 = 'mean of IBM'
        legend3 = "IDE"
        legend4 = "IBM"
        
    if Nsimu<>0:
        mean_biomasse = np.zeros(np.size(np.load(folder + 
                                        '/IBM/Simulation0/Substrate.npy')[:N]))
        mean_substrat = np.zeros(np.size(mean_biomasse))
    for i in xrange(Nsimu-1):
        pl.plot(np.load(folder + 
                        '/IBM/Simulation{0}/Substrate.npy'.format(i))[:N],
                np.load(folder+'/IBM/Simulation{0}/Mass.npy'.format(i))[:N]/V, 
                    color='b', alpha=0.3)
        mean_biomasse += np.load(folder + 
                                 '/IBM/Simulation{0}/Mass.npy'.format(i))[:N]/V
        mean_substrat += np.load(folder + 
                              '/IBM/Simulation{0}/Substrate.npy'.format(i))[:N]

    if Nsimu<>0:
        pl.plot(np.load(folder + 
                       '/IBM/Simulation{0}/Substrate.npy'.format(Nsimu-1))[:N],
                np.load(folder + 
                        '/IBM/Simulation{0}/Mass.npy'.format(Nsimu-1))[:N]/V, 
                color='b', alpha=0.3, label=legend4)
        mean_biomasse += np.load(folder + 
                           '/IBM/Simulation{0}/Mass.npy'.format(Nsimu-1))[:N]/V
        mean_substrat += np.load(folder + 
                        '/IBM/Simulation{0}/Substrate.npy'.format(Nsimu-1))[:N]
    
    if IDE==True:
        pl.plot(np.load(folder+'/IDE/substrate_IDE.npy')[:N], 
                np.load(folder+'/IDE/biomass_IDE.npy')[:N], color='r',
                label=legend3, linewidth=2.5)
    if Nsimu<>0:
        mean_biomasse /= Nsimu
        mean_substrat /= Nsimu
        pl.plot(mean_substrat,mean_biomasse, '--', color=(0,1,0),
                label=legend1, linewidth=2.5)
    pl.legend(loc=1, prop={'size':legendsize})
    pl.tick_params(axis='both', labelsize=tickssize)
    
    #pl.axes().set_aspect(1)
    #pl.Axes.set_aspect('auto', 'box')
    
    if lang=='F':
        pl.savefig(folder+'/portraitPhase.pdf')
        print "The graph of phase portrait is saved in "
        print "   " +  folder+'/portraitPhase.pdf'
    else:
        pl.savefig(folder+'/phasePortrait.pdf')
        print "The graph of the phase portrait is saved in "
        print "   " + folder+'/phasePortrait.pdf'

def density(folder, timearray, Nsimu, steptime, maximalMass, Nbclasses, IDE, 
            lang='F'):
    """
Plot and save in the folder the renormalized mass density of
    - the IBM runs
    - the solution of IDE if IDE=True
at the time determined in the variable timearray        
===========  ==================================================================
parameters            
===========  ==================================================================
folder       folder of the simulation
timearray    array containing the times to plot densities
Nsimu        number of simulation of IBM to plot 
steptime     step of time of data saves
maximalMass  maximal mass of individuals
Nbclasses    number of classes for the histograms of individuals masses of the
             IBM runs
IDE          True to plot the solution of IDE, False if not
lang         language for the legends ('F' = french, otherwise = english)
===========  ==================================================================
"""

    if IDE==True:
        density_det = np.load(folder+'/IDE/density_IDE.npy') 
        x = np.linspace(0, maximalMass, np.size(density_det[0]))

    J = timearray /steptime
    h = maximalMass/Nbclasses
    for j in J:
        pl.clf()
        j = int(j)
        for i in xrange(Nsimu):
            if os.path.exists(folder+'/IBM/Simulation{0}/{1}.npy'.format(i,j))==True:
                data = np.load(folder+'/IBM/Simulation{0}/{1}.npy'.format(i,j))[0]
                pl.hist(data[5:], np.arange(0, maximalMass+h,h), normed=True, 
                    color='b', histtype='stepfilled', alpha=0.05)

        if IDE==True:
            pl.plot(x ,density_det[j], color='r', linewidth = 2)
        pl.yticks([])
        pl.xlim([0,maximalMass])
        
        if lang=='F':
            pl.title(u"densité au temps t=" + str(j*steptime), 
                     fontsize=label_size)
            pl.xlabel('masse (mg)', fontsize=label_size)
            filename = folder + '/densite' + str(j*steptime) + '.pdf'
        else:
            pl.title("density at time t=" + str(j*steptime), 
                     fontsize=label_size)
            pl.xlabel('mass (mg)', fontsize=label_size)
            filename = folder + '/density' + str(j*steptime) + '.pdf'
        pl.xlabel('mass (mg)', fontsize=label_size)
        pl.tick_params(axis='both', labelsize=tickssize)
        pl.savefig(filename, dpi=100)
        print "The graph of the density at time " + str(j*steptime),
        print " is saved in "
        print "   " + filename
            
def IDE(x, density, T, steptime, folder, lang='F'):
    """
Plot and save in the folder the time evolution of the renormalized mass density
of the solution of IDE        
===========  ==================================================================
parameters            
===========  ==================================================================
x   		 array of masses
density      2D-array : density[i][j] is the density of mass x[j] at time
             i*steptime
T            maximal time for the time evolution plot
steptime     step of time of data saves
folder       folder of the simulation
lang         language for the legends ('F' = french, otherwise = english)
===========  ==================================================================
"""    
    nbT = np.size(density.T[0])
    sizex=np.size(x)
    plt.clf()
    fig = plt.figure()
    ax = fig.gca(projection='3d')
    for i in range(nbT):
        ax.plot(np.ones(sizex)*i*steptime,x, density[i], alpha=0.2, color='b')
    
    if lang=='F': 
        ax.set_xlabel("temps", fontsize=label_size)
        ax.set_ylabel("masse", fontsize=label_size)
        ax.set_zlabel(u"densité", fontsize=label_size)
        filename = folder + '/evolution_densite_IDE.pdf'
    else:
        ax.set_xlabel('time (h)', fontsize=label_size)
        ax.set_ylabel('mass (mg)', fontsize=label_size)
        ax.set_zlabel("density", fontsize=label_size)
        filename = folder + '/IDE_density_evolution.pdf'
    pl.tick_params(axis='both', labelsize=tickssize)
    pl.savefig(filename, dpi=100)
    print "The graph of the density evolution of the IDE",
    print " is saved in "
    print "   " + filename  
    
def IDE2(x, density, T, steptime, folder, lang='F'):
    """
Plot and save in the folder the time evolution of the renormalized mass density
of the solution of IDE at 10 times beetween 0 and T        
===========  ==================================================================
parameters            
===========  ==================================================================
x0		     array of masses
density0     2D-array : density0[i][j] is the density of mass x[j] at time
             i*steptime
T            maximal time for the time evolution plot
steptime     step of time of data saves
folder       folder of the simulation
lang         language for the legends (F = french, E = english)
===========  ==================================================================
"""
    nbT = np.size(density.T[0])
    
    plt.clf()
    fig = plt.figure()
    ax = fig.gca(projection='3d')
    
    verts = []
    
    if nbT>=10:
        zs = np.arange(0.0,nbT, int(nbT/10))*steptime

        for i in range(0,nbT, int(nbT/10)):
            y = density[i]
            verts.append(list(zip(x, y)))
    else:
        zs = np.arange(0.0,nbT, 1)*steptime

        for i in range(0,nbT, 1):
            y = density[i]
            verts.append(list(zip(x, y)))
            
    poly = PolyCollection(verts)
    
    poly.set_alpha(0.7)
    ax.add_collection3d(poly, zs=zs, zdir='x')
    
    ax.set_ylim3d(0, max(x))
    ax.set_xlim3d(0, nbT*steptime)
    ax.set_zlim3d(0, np.max(density))

    label_size2 = 18
   
    if lang=='F': 
        ax.set_xlabel("temps (h)", fontsize=label_size2)
        ax.set_ylabel("masse (mg)", fontsize=label_size2)
        ax.set_zlabel(u"densité", fontsize=label_size2)
        filename = folder + '/evolution_densite_IDE2.pdf'
    else:
        ax.set_xlabel('time (h)', fontsize=16)
        ax.set_ylabel('mass (mg)', fontsize=16)
        ax.set_zlabel("density", fontsize=16)
        filename = folder + '/IDE_density_evolution2.pdf'
    pl.tight_layout()
    plt.savefig(filename, dpi=100)     
    print "The graph of the density evolution of the IDE",
    print " at the beginning of the simulation is saved in "
    print "   " + filename 
