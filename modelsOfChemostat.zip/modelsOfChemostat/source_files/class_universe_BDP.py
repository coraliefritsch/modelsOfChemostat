# -*- coding: utf-8 -*-
import random as rd
import numpy as np
import class_efficiency
from scipy.integrate import odeint
import simulationParameters as para

def washout_equation(s,t,s_in,D):
    return D*(s_in-s)

class universe(object):
    'abstract class'
    def numberOfIndividuals(self):
        "number of individuals in the chemostat"
        
    def continuousEvolution(self,tps):
        """evolution of the universe during the time tps given that no event
        occurs during this time."""
    
    def event(self):
        raise NotImplementedError
    
    def gillespie(self,Tmax):
        raise NotImplementedError

class ChemostatBDP(universe):
    def __init__(self,m):
        self.__numberOfIndividuals = para.n0
        self.__substrate = para.S_0
        self.__individualMass = m
        self.__efficiency = class_efficiency.Efficiency()
        
    def numberOfIndividuals(self):
        "number of individuals in the chemostat"
        return self.__numberOfIndividuals

    def mass(self):
        "total biomass in the chemostat"
        return self.__numberOfIndividuals* self.__individualMass
        
    def mu(self, mumax, Ks):
        "Monod kinetics"       
        return mumax * self.__substrate / (Ks+self.__substrate)
   
    def continuousEvolution(self, tps,eulerStep, mumax, Ks):
        """evolution of the substrate concentration during the time tps given
        that no event occurs during this time. The computation of this 
        evolution is realized according to an Euler scheme with fix step time
        `eulerStep' and Monod parameters mumax and Ks."""
        
        nbStep = int(tps/eulerStep)
        i=1
        #Euler scheme
        while i<=nbStep:  
            #substrate consumption
            self.__substrate += eulerStep*(para.D*(para.S_in-self.__substrate)
                                           - para.k * self.mu(mumax,Ks)  
                                           * self.mass()/ para.V)
            i += 1
            
        #last step of the Euler scheme
        tps-=nbStep*eulerStep
        self.__substrate += tps*(para.D*(para.S_in-self.__substrate)
                                - para.k*self.mu(mumax,Ks)*self.mass()/ para.V)
        
    def birth(self):
        self.__numberOfIndividuals +=1

    def death(self):
        self.__numberOfIndividuals -=1
        
    def event(self,tps, maxRate, mumax, Ks):
        """"computation of the next event (birth, washout or rejection)
        by acceptation/rejection method"""

        u = rd.random()*maxRate
        mu_S = self.mu(mumax,Ks)
        if u<mu_S:     
            "birth of an individual"
            self.birth()
            self.__efficiency.acceptance()
        else: 
            if u<(mu_S+para.D):
                "washout"
                self.death()
                self.__efficiency.acceptance()
            else: 
                "rejection"
                self.__efficiency.rejection()
                
    def gillespie(self,Tmax,stepTime, eulerTime,folder, mumax, Ks):
        """Simulates of the evolution of the Crump-Young model by a Gillespie 
        algorithm and save the evolution of the chemostat in .npy files"""
        #memory allocation
        nbind = np.zeros((Tmax/stepTime+1))
        mass = np.zeros((Tmax/stepTime+1))
        substrate = np.zeros((Tmax/stepTime+1))

        maximal_rate = mumax+para.D
                
        #Initialization
        nbind[0] = self.numberOfIndividuals()
        mass[0] = self.mass()
        substrate[0] = self.__substrate
        
        t=0
        l = 1           #number of the next save
        #event iteration until Tmax or the washout
        while t<Tmax and self.numberOfIndividuals()>0:
            delta = rd.expovariate(self.numberOfIndividuals()*maximal_rate)

            #if the time of the next event is bigger than the time of the next
            #save, we first save the population
            while t+delta>=l*stepTime and t<Tmax:            
                self.continuousEvolution(l*stepTime-t, eulerTime, mumax, Ks)
                delta = t+delta-l*stepTime
                t = l*stepTime
                nbind[l] = self.numberOfIndividuals()
                mass[l] = self.mass()
                substrate[l] = self.__substrate
                l += 1
                    
            #substrate consumption during the time delta
            self.continuousEvolution(delta, eulerTime, mumax, Ks)
                
            t += delta                                   #current time update
            self.event(t, maximal_rate, mumax, Ks)       #event
                
        if self.numberOfIndividuals()==0:
            #population extinction
            print "population extinction of one simulation"     
            np.save(folder + '/extinction_time.npy',t)
            
            tps = np.append(t,np.arange(l*stepTime,
                                    Tmax+stepTime/2,stepTime))
            substrate[l:] = odeint(washout_equation,self.__substrate,
                            tps,args=(para.S_in, para.D)).T[0][1:]
                                        
        #save of the evolution of the number of indivduals, the biomass 
        #concentration and the substrate concentration 
        np.save(folder+'/Pop_size_BDP.npy',nbind)
        np.save(folder+'/Mass_BDP.npy',mass)
        np.save(folder+'/Substrate_BDP.npy',substrate)
