# -*- coding:Utf-8 -*-
from scipy.integrate import odeint
import numpy as np
import leastsqbound as lsqb

def monod(s,mumax,Ks):
    return mumax*s/(Ks+s)
    
def system_diff_monod(x,t,mumax,Ks, D, S_in, k):
    return [D*(S_in-x[0]) - k*monod(x[0],mumax,Ks)*x[1] , 
            (monod(x[0],mumax,Ks)-D)*x[1]]
    
def dist_monod(theta,S0,X0,t,massRef,substrateRef, D, S_in, k, t_trans,
               varMass=None, varSubstrate=None, t_compare=None):
    """
Compare the time evolutions of the biomass concentration X and substrate
concentration S of the ODE with the Monod Kinetics with parameters theta=(mu,K)
to massRef and substrateRef during the time t_compare or t if t_compare=None.
Return the distance between the two vectors (X, S) and (massRef, substrateRef)
where the distance is the euclidian distance weighted by the variances varMass
and varSubstrate if they are different from None. A more important weight is 
also given after time t_trans (consider as the transition time between 
transitory state and stationnary state).
"""
    mu, K= theta
    solution = odeint(system_diff_monod,[S0,X0],t,args=(mu,K, D, S_in, k))   
        
    if t_compare is None:
        start = 0
        end = np.size(t)-1
    else:
        start = np.argmax(t==t_compare[0])
        end = np.argmax(t==t_compare[-1])

    if varMass is None:
        sigma2Mass = np.ones(np.size(t))
    else:
        sigma2Mass = varMass
    if varSubstrate is None:
        sigma2Substrate = np.ones(np.size(t))
    else:
        sigma2Substrate = varSubstrate
        
    weightMass = np.ones((end-start+1))
    weightSubstrate = np.ones((end-start+1))
    if t_trans<>0 and t_trans<>None:
        weightMass[np.argmax(t==float(t_trans)):] = (1000000*
                                    sigma2Mass[np.argmax(t==float(t_trans)):])
        weightSubstrate[np.argmax(t==float(t_trans)):] = (1000000*
                                sigma2Substrate[np.argmax(t==float(t_trans)):])
    
    result = np.sqrt(weightMass[start:end+1]*
                    ((massRef[start:end+1]-solution.T[1][start:end+1])**2)
                    /sigma2Mass[start:end+1]
                    +weightSubstrate[start:end+1]*
                    ((substrateRef[start:end+1]-solution.T[0][start:end+1])**2)
                         /sigma2Substrate[start:end+1])
    return result

def initial_theta(mumax_min, mumax_max, Ks_min, Ks_max, s0, x0, t, mass,
                  substrate, D, Sin, k, Ttrans, varmass=None,
                  varsubstrate=None):
    """
return the initial parameter theta=(mu,K) of the Monod kinetics which minimize
the distance in the sense of the one defined in the function dist_monod. The
parameter mu is determined amongst a discretization with 100 points of
[mumax_min, mumax_max] and the parameter K is determined amongst a
discretization with 100 points of [Ks_min, Ks_max]. This point theta is the
starting point for determining the optimal theta in the function
parametres_optimaux.
"""
    step_alphamax = (mumax_max-mumax_min)/100
    step_ks = (Ks_max-Ks_min)/100
    vec_alphamax = np.arange(mumax_min, mumax_max, step_alphamax)
    vec_K_s = np.arange(Ks_min, Ks_max, step_ks) 
    dist = np.zeros((np.size(vec_alphamax), np.size(vec_K_s)))
    for i in range(np.size(vec_alphamax)):
        for j in range(np.size(vec_K_s)):
            theta0 = [vec_alphamax[i],vec_K_s[j]]
            dist[i,j] = np.sum(dist_monod(theta0,s0,x0,t,mass,substrate, D,
                                Sin, k, Ttrans, varmass, varsubstrate)**2)

    index = np.unravel_index(np.argmin(dist), dist.shape)
    theta = [vec_alphamax[index[0]], vec_K_s[index[1]]]
    return theta

def optimal_parameters(mumax_min, mumax_max, Kmin, Kmax, s0, x0, t, 
                        biomassRef, substrateRef, D, s_in, k, tcompare,
                        t_transitory=None, variance_biomassRef=None,
                        variance_substrateRef=None):
    """
return the parameter theta_optimal=(mumax,K) of the Monod kinetics which
minimize the distance in the sense of the one defined in the function
dist_monod
"""
    theta0 = initial_theta(mumax_min, mumax_max, Kmin, Kmax, s0, x0, t, 
                            biomassRef, substrateRef, D, s_in, k, t_transitory,
                            variance_biomassRef, variance_substrateRef)  

    theta_optimal = lsqb.leastsqbound(dist_monod, theta0,
                        args=(s0, x0, t, biomassRef, substrateRef, D, s_in, k,
                             t_transitory, variance_biomassRef,
                             variance_substrateRef, tcompare),
                        bounds=[(mumax_min,mumax_max), (Kmin,Kmax)])[0]
    return theta_optimal
