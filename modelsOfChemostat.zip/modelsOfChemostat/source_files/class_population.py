# -*- coding: utf-8 -*-
import numpy as np
import class_individual as ci
import simulationParameters as simupara
import random as rd

class Population(object):
    'abstract class'
    def massesOfIndividuals(self):
        '''return a table with the masses of indivudals of the population'''
    
    def numberOfIndividuals(self):
        "return the number of individuals of the population"
    
    def totalMass(self):
        "return the total biomass of the population"
    
    def individual(self,individualIndex):
        "return the individual number individualIndex of the population"
    
    def individuals(self):
        "return a table containing the individuals of the population"
    
    def changeMasses(self,newMasses):
        "change the masses of individuals by newMasses"
    
    def death(self, i):
        "modify the population in the case of death of the individual number i"
                
    def division(self,i,tps):
        """modify the population in the case of division of the individual 
        number i"""
            
class PointerPopulation(Population):
    '''a population is defined by:
        - a table of masses of individuals .__tabMasses
        - a table of individual of class PointerIndividual .__individuals
        - the number of individuals of the population .__numberOfIndividuals
    '''
    
    def __init__(self):
        '''initialization of the population'''
        nbindividuals = simupara.n0
        
        maximaleSize = 10*nbindividuals
        self.__tabMasses = np.zeros(maximaleSize)         
            
        #initial individuals are distributed according to the density
        #defined in the parameters file : parameters.initialDensity
        h = 0.001*simupara.M   
        mass = np.arange(0,simupara.M,h)+h/2
        proba = simupara.initialDensity(mass)
        proba = proba / np.sum(proba)
           
        for i in range(nbindividuals):
            self.__tabMasses[i]+=mass[
                                     int(np.sum(np.cumsum(proba)<rd.random()))]
        
        self.__individuals = ([ci.PointerIndividual(self.__tabMasses,0,0)]
                            *maximaleSize)
        for i in range(nbindividuals):
            self.__individuals[i] = ci.PointerIndividual(self.__tabMasses,0,i)
            
        self.__numberOfIndividuals = nbindividuals
    
    def massesOfIndividuals(self):
        '''return a table with the masses of indivudals of the population'''
        return self.__tabMasses[:self.__numberOfIndividuals]
    
    def numberOfIndividuals(self):
        "return the number of individuals of the population"
        return self.__numberOfIndividuals
    
    def totalMass(self):
        "return the total biomass of the population"
        return np.sum(self.__tabMasses[:self.__numberOfIndividuals])
    
    def individual(self,individualIndex):
        "return the individual number individualIndex of the population"
        return self.__individuals[individualIndex]
    
    def individuals(self):
        "return a table containing the individuals of the population"
        return self.__individuals[:self.__numberOfIndividuals]
    
    def changeMasses(self,newMasses):
        "change the masses of individuals by newMasses"
        self.__tabMasses[:self.__numberOfIndividuals] = newMasses
    
    def death(self, i):
        "modify the population in the case of death of the individual number i"
        self.__numberOfIndividuals -= 1
        self.__individuals[i] = self.__individuals[self.__numberOfIndividuals]
        self.__individuals[i].changeIndex(i)
        self.__tabMasses[i] = self.__tabMasses[self.__numberOfIndividuals]
        
    def division(self,i,divisionTime):
        '''modify the population in the case of division of the individual 
        number i.
        The birth dates of the 2 new individuals are divisionTime'''
        massx = self.__tabMasses[i] #mass of the individual which divides
        x = self.__individuals[i]      #the individual which divides
        massy = x.massAfterDivision()
        #massy is the mass of on daughter individual from the division
        
        #we modifiy the mass and the birth date of the invidual which divides 
        self.__tabMasses[i] = massy
        self.__individuals[i].changeBirthDate(divisionTime)
        
        #we create the second individual
        self.__tabMasses[self.__numberOfIndividuals] = massx-massy
        self.__individuals[
            self.__numberOfIndividuals] = ci.PointerIndividual(
                                                self.__tabMasses, divisionTime,
                                                self.__numberOfIndividuals)
        #there is one individual more in the population
        self.__numberOfIndividuals += 1    
        
    def memoryCapacity(self):
        '''return the number of individuals wich can be described in the 
        population. This number corresponds to the size of the table 
        self.__tabMasses'''
        return np.size(self.__tabMasses)
        
    def memoryManagement(self, newSize):
        '''change the size of the tables self.__tabMasses and 
        self.__individuals. The new size of the tables is newSize. The first 
        index of the new tables are the same of the old tables.'''

        oldSize = np.size(self.__individuals)
        
        #we change the size of the tables .__tabMasses et .__individus
        self.__tabMasses.resize(newSize, refcheck=False)
        self.__individuals += (ci.PointerIndividual(self.__tabMasses,0,0)
                           .listeOfIndividuals(newSize-oldSize,
                                           oldSize))
        
        #The adress of the pointers of the individuals to the table 
        #self.__tabMasses is lost; we create the new adress
        for ind in self.__individuals[:oldSize]:
            ind.changeAdressMassTab(self.__tabMasses)
