# -*- coding:Utf-8 -*-
from scipy.integrate import odeint
import numpy as np
#import matplotlib
#matplotlib.use('Agg')
import pylab as pl
import leastsquares as MC
import shutil
import os
import sys
import meanVariance as MV

label_size = 22      #font size of the labels
legende_size = 22    #font size of the legends
ticks_size = 18      #font size of the ticks

def monod(s,mumax,Ks):
    'return the monod kinetic'
    return mumax*s/(Ks+s)
    
def system_diff_monod(x,t,mumax,Ks, D, S_in, k):
    'monod ODE system of equations'
    return [D*(S_in-x[0]) - k*monod(x[0],mumax,Ks)*x[1] , 
            (monod(x[0],mumax,Ks)-D)*x[1]]

def ODE(folder, language, ODE_IDE = False,  ODE_IBM = True,
        ODE_IBM_cond = False, ODE_by_default = False, tminMC=0,
        tmaxMC=None, nbsimu=0, mumax_EDO = 0.9, Ks_EDO = 10, pond = True, 
        log_biomass_scale = False):
    '''compute the parameters of the ODE model with a Monod kinetic by a least
    squares method on the
    - IBM model if ODE_IBM is True
    - IDE model if ODE_IDE is True
    - non extinct simulations of the IBM model if  ODE_IBM_cond is True
    or with ODE parameters enter by the user is ODE_by_default is not False
    but default parameters.
    For each case, evolutions of biomass and substrate concentration and the
    concentration trajectories in the phase space are plotted.
    '''
    #Save python files
    if os.path.exists(folder+'/source_files')==False: 
        os.mkdir(folder+'/source_files')   
    shutil.copy("source_files/leastsquares.py", folder+'/source_files')
    shutil.copy("source_files/leastsqbound.py", folder+'/source_files')
    
    #Parameters of the simulations
    sys.path.append(os.getcwd()+'/'+folder+'/source_files')
    import simulationParameters

    Tmax = np.float(simulationParameters.T)
    stepTime = np.float(simulationParameters.save_step_time)
    V = np.float(simulationParameters.V)
    D = np.float(simulationParameters.D)
    S_in = np.float(simulationParameters.S_in)
    S0 = np.float(simulationParameters.S_0)
    k = np.float(simulationParameters.k)
    K_s = np.float(simulationParameters.Ks)
    alphamax = np.float(simulationParameters.mumax)
    mmax = np.float(simulationParameters.M)
    n0 = np.float(simulationParameters.n0)
    nbsimu_IBM = simulationParameters.Nbsimu

    if nbsimu>nbsimu_IBM or nbsimu==0:
        nbsimu = nbsimu_IBM

    if os.path.exists(folder+'/IDE/substrate_IDE.npy'):
        plotIDE = True
        substrateIDE = np.load(folder+'/IDE/substrate_IDE.npy')
        biomassIDE = np.load(folder+'/IDE/biomass_IDE.npy')
    else:
	plotIDE = False
    
    #means and variances of the IBM simulations
    [nonExtinctSimu, meanMass, meanSubstrate, varMass, varSubstrate,
    meanSizePop, massMoyenne_nonExtinct, meanSubstrate_nonExtinct,
    varMass_nonExtinct,
    varSubstrate_nonExtinct] = MV.mean_var_IBM(folder, nbsimu)

    X_0 = meanMass[0]
    S_0 = meanSubstrate[0]
    
    if plotIDE:
        X_0_det = biomassIDE[0]
    else:
        h = np.float(simulationParameters.M)/1000.0
        x = np.arange(0, np.float(simulationParameters.M)+h/2, h) 
        p = simulationParameters.initialDensity(x)
        p = p*n0/(np.sum(p)*h)
        X_0_det = h * np.dot(x,p)/V
    
    """************************************************************************
    ************ L E A S T   S Q U A R E S   M E T H O D **********************
    ************************************************************************"""
    #Calculus of the ODE parameters K_s and mumax by a least squares method
    tmin = int(tminMC/stepTime)*stepTime
    if tmaxMC==None:
        t_compare = (tmin, Tmax+stepTime/2, stepTime) 
    else:
        tmax = min(int(tminMC/stepTime)*stepTime, Tmax)
        t_compare = (tmin, tmax+stepTime/2, stepTime)
        
    t = np.arange(0, Tmax+stepTime/2, stepTime) 

    Kmin=0.1
    Kmax= 200.0
    mumax_min=0.01
    mumax_max=20.0
    
    if tmaxMC==None or tmaxMC>Tmax:
        t_compare = t*1
    else:
        t_compare = np.arange(tminMC, tmaxMC+ stepTime/2.0, stepTime)
    

    theta0 = [alphamax,K_s]
        
    if ODE_IDE:
        thetaopt_IDE = MC.optimal_parameters(mumax_min, mumax_max, Kmin, Kmax,
                                     S_0, X_0_det, t, biomassIDE, substrateIDE,
                                     D, S_in, k, t_compare)
    
        solution_IDE=odeint(system_diff_monod,[S_0,X_0_det],t,
                            args=(thetaopt_IDE[0],thetaopt_IDE[1], D, S_in, k))

    if ODE_IBM:
        if pond == False:
            varMass_MC = None
            varSubstrate_MC = None
        else: 
            varMass_MC = varMass
            varSubstrate_MC = varSubstrate

        thetaopt_IBM = MC.optimal_parameters(mumax_min, mumax_max, Kmin, Kmax,
                          S_0, X_0, t, meanMass, meanSubstrate, D, S_in, k,
                          t_compare, None, varMass_MC, varSubstrate_MC)

        solution_IBM=odeint(system_diff_monod,[S_0,X_0],t,
                            args=(thetaopt_IBM[0],thetaopt_IBM[1], D, S_in, k))

    if ODE_IBM_cond:
        if pond == False:
            varMassCond_MC = None
            varSubstrateCond_MC = None
        else: 
            varMassCond_MC = varMass
            varSubstrateCond_MC = varSubstrate

        thetaopt_IBM_cond = MC.optimal_parameters(mumax_min, mumax_max, Kmin,
                             Kmax, S_0, X_0, t, massMoyenne_nonExtinct, 
                             meanSubstrate_nonExtinct, D, S_in, k, 
                             t_compare, None, varMassCond_MC, 
                             varSubstrateCond_MC)
    
        solution_IBM_cond=odeint(system_diff_monod,[S_0,X_0],t,
                            args=(thetaopt_IBM_cond[0],thetaopt_IBM_cond[1], 
                                  D, S_in, k))

    if ODE_by_default:
        solution_EDO = odeint(system_diff_monod,[S_0,X_0_det],t,
                            args=(mumax_EDO,Ks_EDO, D, S_in, k))

    print folder
    print "Parameters of the ODE :"
    if ODE_IDE:
        print "least squares method on the integro-differential equation :"
        print r"   (\mu_\max, K_s)=", thetaopt_IDE
    if ODE_IBM:
        print "least squares method on the IBM :"
        print r"   (\mu_\max, K_s)=", thetaopt_IBM

    if ODE_IBM_cond:
        print "least squares method on the IBM given the non extinction:"      
        print r"   (\mu_\max, K_s)=", thetaopt_IBM_cond

    if ODE_by_default:
        print "parameters of the ODE by default:"      
        print r"   (\mu_\max, K_s)=", [mumax_EDO, Ks_EDO]

    text = 'The parameters of the ODEs are :\n \n'    
    if ODE_IDE:
        text = text + "least squares method on the integro-differential ",
        text = text + "equation :\n"
        text = text + r"   $(\mu_\max, K_s)=$" + str(thetaopt_IDE) + '\n'
    if ODE_IBM:
        text = text + "least squares method on the IBM :\n"
        text = text + r"   $(\mu_\max, K_s)=$" + str(thetaopt_IBM) + '\n'

    if ODE_IBM_cond:
        text = text + "least squares method on the IBM given the non ",
        text = text + "extinction:\n"      
        text = text + r"   $(\mu_\max, K_s)=$" + str(thetaopt_IBM_cond) +'\n'

    if ODE_by_default:
        text = text + "parameters of the ODE by default:\n"      
        text = text + r"   $(\mu_\max, K_s)=$" + str([mumax_EDO, Ks_EDO])
        text = text + ' \n'

    text = text + ("The plots are matched on the time interval : " 
                    + str([min(t_compare), max(t_compare)])) + '\n \n'
    
    if pond :
        text = text + "The IBMs runs are weighted by their variance"
    else:
        text = text + "The IBMs runs are not weighted by their variance"
    file(folder + '/ODE_parameters.txt', 'w').write(text)


    """************************************************************************
    **************************** G R A P H I C ********************************
    ************************************************************************"""
    
    pl.rcParams['legend.loc'] = 'best'
    
    #legends
    if language=='F':
        label_mean = 'moyenne'
        label_mean_non_ext = 'moyenne | non lessivage'
        label_IDE = 'EID'
        label_substrate = 'concentration en substrat (mg/l)'
        label_biomass = 'concentration en biomasse (mg/l)'
        label_time = 'temps (h)'
        label_ODE_IDE = 'EDO IDE'
        label_ODE_IBM = 'EDO'
        label_ODE_IBM_stat = 'EDO 2'
        label_ODE_IBM_cond = 'EDO cond'
        label_ODE = 'EDO'
    else:
        label_mean = 'mean'
        label_mean_non_ext = 'mean | Non-W'
        label_IDE = 'IDE'
        label_substrate = 'substrate concentration(mg/l)'
        label_biomass = 'biomass concentration (mg/l)'
        label_time = 'time (h)'
        label_ODE_IDE = 'ODE IDE'
        label_ODE_IBM = 'ODE IBM'
        label_ODE_IBM_cond = 'ODE IBM cond'
        label_ODE_IBM_stat = 'ODE 2'
        label_ODE = 'EDO'
    
    Lline = 2
    
    #Plot of the trajectories in the phase portrait
    pl.clf()
    for i in range(int(nbsimu)):    
        pl.plot(np.load(folder+'/IBM/Simulation{0}/Substrate.npy'.format(i)),
                np.load(folder+'/IBM/Simulation{0}/Mass.npy'.format(i))/V, 
                color='b', alpha=0.1)
    if plotIDE:
        pl.plot(substrateIDE, biomassIDE, color='r', 
                label=label_IDE, linewidth = Lline)
    
    if (meanSubstrate_nonExtinct<>meanSubstrate).any() :
        pl.plot(meanSubstrate_nonExtinct,massMoyenne_nonExtinct, '--', 
                color=(0,1,0), label=label_mean_non_ext, 
                linewidth = Lline)
    else:
        pl.plot(meanSubstrate_nonExtinct,massMoyenne_nonExtinct, '--', 
                color=(0,1,0), label=label_mean, linewidth = Lline)
    
    if ODE_IDE:
        pl.plot(solution_IDE.T[0],solution_IDE.T[1], 'k-.',linewidth = Lline, 
                label=label_ODE_IDE, alpha=0.75)
    if ODE_IBM:
        pl.plot(solution_IBM.T[0],solution_IBM.T[1], 'k-.',linewidth = Lline, 
                label=label_ODE_IBM, alpha=0.75)
    if ODE_IBM_cond:
        pl.plot(solution_IBM_cond.T[0],solution_IBM_cond.T[1], 
                'k-.',linewidth = Lline, label=label_ODE_IBM_cond, alpha=0.75)
    if ODE_by_default:
        pl.plot(solution_EDO.T[0],solution_EDO.T[1], 'k-.',linewidth = Lline, 
                label=label_ODE_IBM_cond, alpha=0.75)
    
    pl.legend(prop={'size':legende_size})
    
    pl.xlabel(label_substrate, fontsize=label_size)
    pl.ylabel(label_biomass, fontsize=label_size)
    pl.tick_params(axis='both', labelsize=ticks_size)
    
    if log_biomass_scale:
        pl.yscale('log')
    if language=='F':
        filename = folder + '/EDO_phase_f.pdf'
    else:
        filename = folder + '/ODE_phase_e.pdf'
    pl.savefig(filename, dpi=100)
    print "The graph of the portrait phase",
    print " is saved in "
    print "   " + filename
    
    #plot of the time evolution of the biomass concentration
    n = 1
    t0 = 0
    T = Tmax
    N0 = int(T/stepTime)+1
    n0 = int(t0/stepTime)
    
    pl.clf()   
    nblessivage = 0
    for i in range(int(nbsimu)):    
        if np.load(folder+'/IBM/Simulation{0}/Mass.npy'.format(i))[-1] ==0 :
            pl.plot(t[n0:N0:n], np.load(folder+
                                        '/IBM/Simulation{0}/Mass.npy'
                                        .format(i))[n0:N0:n]/V, 
                color='b', alpha=0.03)
            nblessivage += 1
        else:
            pl.plot(t[n0:N0:n], np.load(folder+
                                        '/IBM/Simulation{0}/Mass.npy'
                                        .format(i))[n0:N0:n]/V, 
                color='b', alpha=0.1)
    if plotIDE:
        pl.plot(t[n0:N0:n], biomassIDE[n0:N0:n], color='r', label=label_IDE, 
                linewidth = Lline)
    
    if (meanSubstrate_nonExtinct<>meanSubstrate).any() :
        pl.plot(t[n0:N0:n],meanMass[n0:N0:n], color=(0,1,0), 
                label=label_mean, linewidth = Lline)
        pl.plot(t[n0:N0:n],massMoyenne_nonExtinct[n0:N0:n],'--', 
                color=(0,1,0), label=label_mean_non_ext, linewidth = 1)
    else:
        pl.plot(t[n0:N0:n],massMoyenne_nonExtinct[n0:N0:n], '--', 
                color=(0,1,0), label=label_mean, linewidth = Lline)
            
    if ODE_IDE:
        pl.plot(t[n0:N0:n],solution_IDE.T[1][n0:N0:n], 'k-.',linewidth = Lline,
                 label=label_ODE_IDE, alpha=0.75)
    if ODE_IBM:
        pl.plot(t[n0:N0:n],solution_IBM.T[1][n0:N0:n], 'k-.',linewidth = 3, 
                label=label_ODE_IBM, alpha=0.75)
    if ODE_IBM_cond:
        pl.plot(t[n0:N0:n],solution_IBM_cond.T[1][n0:N0:n], 'k-.',linewidth =3,
                 label=label_ODE_IBM_cond, alpha=0.75)
    if ODE_by_default:
        pl.plot(t[n0:N0:n],solution_EDO.T[1][n0:N0:n], 'k-.',linewidth = 3, 
                label=label_ODE, alpha=0.75)
    
    pl.legend(prop={'size':legende_size})
    pl.ylabel(label_biomass, fontsize=label_size)
    if log_biomass_scale:
        pl.yscale('log')        
    
    pl.xlabel(label_time, fontsize=label_size)
    pl.tick_params(axis='both', labelsize=ticks_size)
    pl.tick_params(axis='y', labelsize=15)
    if language=='F':
        filename = folder + '/EDO_biomasse.pdf'
    else:
        filename = folder + '/ODE_biomass.pdf'
    pl.savefig(filename, dpi=100)
    print "The graph of the biomass",
    print " is saved in "
    print "   " + filename
    
    #plot of the time evolution of the substrate concentration
    pl.clf()
    for i in range(int(nbsimu)):    
        pl.plot(t,np.load(folder+'/IBM/Simulation{0}/Substrate.npy'.format(i)),
                 color='b', alpha=0.1)
    if plotIDE:
        pl.plot(t, substrateIDE, color='r', label=label_IDE, linewidth = Lline)
    
    if (meanSubstrate_nonExtinct<>meanSubstrate).any() :
        pl.plot(t,meanSubstrate, color=(0,1,0),label=label_mean, 
                linewidth = Lline)
        pl.plot(t,meanSubstrate_nonExtinct, '--', color=(0,1,0), 
                label=label_mean_non_ext, linewidth = 1)
    else:
        pl.plot(t,meanSubstrate_nonExtinct, '--', color=(0,1,0), 
                label=label_mean, linewidth = Lline)
        
    if ODE_IDE:
        pl.plot(t,solution_IDE.T[0], 'k-.',linewidth = Lline, 
                label=label_ODE_IDE, alpha=0.75)
    if ODE_IBM:
        pl.plot(t,solution_IBM.T[0], 'k-.',linewidth = 3, 
                label=label_ODE_IBM, alpha=0.75)
    if ODE_IBM_cond:
        pl.plot(t,solution_IBM_cond.T[0], 'k-.',linewidth = 3, 
                label=label_ODE_IBM_cond, alpha=0.75)
    if ODE_by_default:
        pl.plot(t,solution_EDO.T[0], 'k-.',linewidth = 3, 
                label=label_ODE, alpha=0.75)
      
    pl.xlabel(label_time, fontsize=label_size)
    pl.ylabel(label_substrate, fontsize=label_size)
    pl.tick_params(axis='both', labelsize=ticks_size)
    pl.legend(prop={'size':legende_size})
    if language=='F':
        filename = folder + '/EDO_substrat.pdf'
    else:
        filename = folder + '/ODE_substrate.pdf'
    pl.savefig(filename, dpi=100)
    print "The graph of the substrate",
    print " is saved in "
    print "   " + filename
