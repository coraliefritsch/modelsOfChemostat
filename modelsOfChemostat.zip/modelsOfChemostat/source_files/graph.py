# -*- coding: utf-8 -*-
import curves
import numpy as np
import os
import sys
import shutil

def plot_curves(folderName,nbsimuIBM, plotIDE, language, nbHistoInter,
                 density_time, plotBDP=False):
    """
Plot the time evolution of simulations. The following files are added in the 
folder folderName (the file names depends of the language):
    - size.pdf or taille.pdf : time evolution of the number of individuals
    - biomass.pdf of biomasse.pdf : time evolution of the biomass concentration
    - substrate.pdf or substrat.pdf : time evolution of the substrate 
      concentration
    - phasePortrait.pdf or portraitPhase.pdf : phase portrait
    - densityxxx.pdf or densitexxx.pdf : density at time xxx for each xxx in
      density_time
    - evolution_densite_IDE.pdf or IDE_density_evolution.pdf : time evolution
      of the renormalized mass density of the solution of IDE        
    - evolution_densite_IDE2.pdf or IDE_density_evolution2.pdf : time evolution
      of the renormalized mass density of the solution of IDE at 10 times
      at the beginning of the simulation
===========  ==================================================================
parameters            
===========  ==================================================================
folderName   folder with the simulation parameters
nbsimuIBM    number of IBM runs to plot 
plotIDE      boolean variable (True for the plot of the IDE model)
language     language for the legends ('F' = french, otherwise = english)
nbHistoInter number of classes in the histogram
density_time array of times for which the mass densities are plotted
plotBDP      boolean variable (True for the plot of the BDP model)
===========  ==================================================================
"""
    #save the python files
    if os.path.exists(folderName+'/source_files')==False:
        os.mkdir(folderName+'/source_files')   
    shutil.copy("source_files/graph.py", folderName+'/source_files')
    shutil.copy("source_files/curves.py", folderName+'/source_files')
    
    #recovery of the simulation parameters
    sys.path.append(os.getcwd()+'/'+folderName+'/source_files')
    import simulationParameters
    Tmax = np.float(simulationParameters.T)
    step_time = np.float(simulationParameters.save_step_time)
    V = np.float(simulationParameters.V)
    mmax = np.float(simulationParameters.M)
    nbsimurun = simulationParameters.Nbsimu
        
    if nbsimuIBM<>'a':
        try:
            nbsimuIBM = int(nbsimuIBM)
        except ValueError:
            pass
        nbsimu = min(nbsimuIBM, nbsimurun)

    if os.path.exists(folderName+'/IBM')==False:
        nbsimu = 0
        
    if plotIDE==True:
        density_det = np.load(folderName+'/IDE/density_IDE.npy')
    
    if plotIDE==True:
        x = np.linspace(0, mmax, np.size(density_det[0]))
    
    Tbis= min(30.0,Tmax)

    if nbsimu==0 and plotIDE==False and plotBDP==False:
        print "no simulation to plot"
    else:
        curves.number_of_individuals(folderName, nbsimu, 0, Tmax, step_time,
                                 plotIDE,language, BDP=plotBDP)
        curves.biomass(folderName, nbsimu, Tmax, step_time,V,plotIDE, language,
                   BDP=plotBDP)
        curves.substrate(folderName, nbsimu, Tmax, step_time,plotIDE, language,
                     BDP=plotBDP)
        curves.phase_portrait(folderName, nbsimu, Tmax, step_time,V,plotIDE, 
                          language)
        curves.density(folderName, density_time, nbsimu, step_time, mmax, 
                    nbHistoInter,plotIDE, language)
    
    N = Tbis/step_time
    if plotIDE==True:
        curves.IDE(x, density_det, Tmax, step_time, folderName, language)
        curves.IDE2(x, density_det[:N+1], Tbis, step_time, folderName,
                     language)
