# -*- coding:Utf-8 -*-
import numpy as np
import os
import sys

def mean_var_IBM(folder, nbsimu):
    '''
return [NbSurvPop, meanMass, meanSubstrate, varMass, varSubstrate, meanSizePop,
meanMass_non_extinct, meanSubstrate_non_extinct, varMass_non_extinct,
varSubstrate_non_extinct] with
NbSurvPop: number of non extinct population
meanMass: mean biomass concentration
meanSubstrate: mean substrate concentration
varMass: variance of the biomass concentration
varSubstrate: variance of the substrate concentration
meanSizePop: the mean number of individualsmeanMass_non_extinct: mean biomass concentration of non extinct population
meanSubstrate_non_extinct: mean substrate concentration of non extinct
population
varMass_non_extinct : variance of the biomass concentration of non extinct
population
varSubstrate_non_extinct: variance of the substrate concentration of non 
extinct population
for the first nbsimu simulations of IBM of the simulation folder
'''
    #Parameters of the simulations
    sys.path.append(os.getcwd()+'/'+folder+'/source_files')
    import simulationParameters
    Tmax = np.float(simulationParameters.T)
    pas_tps = np.float(simulationParameters.save_step_time)
    V = np.float(simulationParameters.V)
    n0 = np.float(simulationParameters.n0)
    
    nb_data=int(simulationParameters.T/simulationParameters.save_step_time)+1
    
    #memory allocation
    meanMass = np.zeros((nb_data))
    meanSubstrate = np.zeros((nb_data))
    varMass = np.zeros((nb_data))
    varSubstrate = np.zeros((nb_data))

    meanSizePop = np.zeros((nb_data))
    
    meanMass_non_extinct = np.zeros((nb_data))
    meanSubstrate_non_extinct = np.zeros((nb_data))
    varMass_non_extinct = np.zeros((nb_data))
    varSubstrate_non_extinct = np.zeros((nb_data))
    
    NbSurvPop=0
    for i in range(int(nbsimu)):
        size = np.load(folder+'/IBM/Simulation{0}/Pop_size.npy'.format(i))
        mass = np.load(folder+'/IBM/Simulation{0}/Mass.npy'.format(i))
        substrate =np.load(folder+'/IBM/Simulation{0}/Substrate.npy'.format(i))
        if mass[-1]<>0:
            NbSurvPop += 1
            meanMass_non_extinct += mass
            meanSubstrate_non_extinct += substrate
            varMass_non_extinct += mass**2
            varSubstrate_non_extinct += substrate**2
        meanMass += mass
        meanSubstrate += substrate
        varMass += mass**2
        varSubstrate += substrate**2
        meanSizePop += size

    meanMass /= nbsimu*V
    meanSubstrate /= nbsimu
    varMass /= nbsimu*(V**2)
    varMass -= meanMass**2
    varSubstrate /= nbsimu
    varSubstrate -= meanSubstrate**2
    meanSizePop /= nbsimu
    
    if NbSurvPop<>0:
        meanMass_non_extinct /= NbSurvPop*V
        meanSubstrate_non_extinct /= NbSurvPop
        varMass_non_extinct /= NbSurvPop*(V**2)
        varMass_non_extinct -= meanMass_non_extinct**2
        varSubstrate_non_extinct /= NbSurvPop
        varSubstrate_non_extinct -= meanSubstrate_non_extinct**2
    else:
        meanMass_non_extinct = meanMass
        meanSubstrate_non_extinct = meanSubstrate
        varMass_non_extinct = varMass
        varSubstrate_non_extinct = varSubstrate

    varMass[varMass==0] = 0.0000001
    varSubstrate[varSubstrate==0] = 0.0000001
    varMass_non_extinct[varMass_non_extinct==0] = 0.0000001
    varSubstrate_non_extinct[varSubstrate_non_extinct==0] = 0.0000001

    return [NbSurvPop, meanMass, meanSubstrate, varMass, varSubstrate,
            meanSizePop, meanMass_non_extinct, meanSubstrate_non_extinct,
            varMass_non_extinct, varSubstrate_non_extinct]
