# -*- coding: utf-8 -*-
import random as rd
import numpy as np
import class_population as cp
import class_efficiency
from scipy.integrate import odeint
import simulationParameters as para

def washout_susbtrate_equation(s,t,s_in,D):
    return D*(s_in-s)

class universe(object):
    'abstract type'
    def numberOfIndividuals(self):
        raise NotImplementedError
    def continuousEvolution(self,tps):
        raise NotImplementedError
    def event(self):
        raise NotImplementedError
    def gillespie(self,Tmax):
        raise NotImplementedError
            
class Chemostat(universe):
    def __init__(self):
        self.__population = cp.PointerPopulation()
        self.__substrate = para.S_0
        self.__efficiency = class_efficiency.Efficiency()

    def numberOfIndividuals(self):
        'number of individuals in the chemostat'
        return self.__population.numberOfIndividuals()

    def growthSpeed(self):
        'growth speed of the individuals'
        return (para.mu(self.__substrate)
                *para.g(self.__population.massesOfIndividuals()))
        
    def continuousEvolution(self, tps,stepTime,cstS):
        '''time evolution of the system during a time tps with an Euler step
        stepTime and cstS = 1/V'''
                        
        Nbpas=int(tps/stepTime)
        i=1
        #Euler scheme
        while i<=Nbpas:  
            #growth of individuals
            grow_pop = self.growthSpeed()
            self.__population.changeMasses(
                                       self.__population.massesOfIndividuals()
                                       +stepTime*grow_pop)
            #consumed substrate
            createdMass = para.k*np.sum(grow_pop)
            #consumption of the substrate during an Euler step time
            self.__substrate += stepTime*(para.D*(para.S_in
                                                -self.__substrate)
                                           -cstS*createdMass)
            i += 1
        
        #last step of the Euler scheme
        tps-=Nbpas*stepTime
        #growth of individuals
        grow_pop=self.growthSpeed()  
        self.__population.changeMasses(self.__population.massesOfIndividuals()
                                       +tps*grow_pop)
        #consumed substrate
        createdMass = para.k*np.sum(grow_pop)
        self.__substrate += tps*(para.D*(para.S_in-self.__substrate)
                                -cstS*createdMass)
        
    def event(self,tps, maxrate):
        '''simulation of the event at time tps by a acceptance/rejection
        methode'''
        i = rd.randint(0,self.__population.numberOfIndividuals()-1)
        x = self.__population.individual(i)
        u = rd.random()*maxrate
        rate_x = para.divisionRate(x.mass())
        
        if u<rate_x:
            #division
            self.__population.division(i,tps)
            self.__efficiency.acceptance()
            
            if (self.__population.numberOfIndividuals()
                ==self.__population.memoryCapacity()):
                #the array of the individuals is full. We add allocated memory
                self.__population.memoryManagement(2
                            *self.__population.memoryCapacity())
        else: 
            if u<(rate_x+para.D):
                #washout
                self.__population.death(i)
                self.__efficiency.acceptance()
            else: 
                #rejection
                self.__efficiency.rejection()
                
    def saveData(self,time, folderName, l):
        np.save(folderName+'/{0}.npy'.format(l),
                        [np.append([time,
                                    self.__substrate,
                                    self.__population.numberOfIndividuals(),
                                    self.__population.totalMass(),
                                    self.__efficiency.getAcceptanceRate()],
                                    self.__population.massesOfIndividuals())]) 
    
    def gillespie(self,Tmax,saveStepTime, eulerStepTime,saveFolderName):
        """Simulates of the evolution of thegrowth-fragmentation-death
        chemostat IBM by a Gillespie algorithm and save the evolution of the
        chemostat in .npy files"""
        
        cst_eqS = (1.0/para.V)
        
        #maximal rate for each individual
        maxRateByIndividual = para.max_div_rate+para.D
        
        #Allocation of memory
        nbind = np.zeros((Tmax/saveStepTime+1))
        mass = np.zeros((Tmax/saveStepTime+1))
        substrate = np.zeros((Tmax/saveStepTime+1))
        
        #initialisation
        nbind[0] = self.__population.numberOfIndividuals()
        mass[0] = self.__population.totalMass()
        substrate[0] = self.__substrate
        
        t=0
        
        self.saveData(t,saveFolderName,0)
        l = 1           #number of the next save
        
        #iterations of events till time Tmax or the washout
        while t<Tmax and self.numberOfIndividuals()>0:
            #simulation of the next event time (T+t) 
            popRate = (maxRateByIndividual
                                    *self.__population.numberOfIndividuals())
                
            delta=rd.expovariate(np.sum(popRate))

            #if the time of the next event is bigger that the next save time
            #we make the population grow and we save it               
            while t+delta>=l*saveStepTime and t<Tmax:            
                self.continuousEvolution(l*saveStepTime-t, eulerStepTime ,
                                         cst_eqS)
                delta = t+delta-l*saveStepTime
                t = l*saveStepTime
                nbind[l] = self.__population.numberOfIndividuals()
                mass[l] = self.__population.totalMass()
                substrate[l] = self.__substrate
                self.saveData(t,saveFolderName,l)
                l += 1

            #evolution of the chemostat during the time delta
            self.continuousEvolution(delta, eulerStepTime,cst_eqS)
                
            #update of the current time
            t += delta                
            
            #event (division, washout or reject)  
            self.event(t, maxRateByIndividual)
            
        if self.numberOfIndividuals()==0:
            #Extinction of the population
            print "extinction of the population of one simulation"     
            np.save(saveFolderName+'/extinction_time.npy',t)
            tps = np.append(t,np.arange(l*saveStepTime,
                                    Tmax+saveStepTime/2,saveStepTime))
            substrate[l:] = odeint(washout_susbtrate_equation,
                                   self.__substrate, tps,
                                   args=(para.S_in, para.D)).T[0][1:]
                                        
        #save of the evolution of the population size and of the biomass
        #and substrate concentrations
        np.save(saveFolderName+'/Pop_size.npy',nbind)
        np.save(saveFolderName+'/Mass.npy',mass)
        np.save(saveFolderName+'/Substrate.npy',substrate)
