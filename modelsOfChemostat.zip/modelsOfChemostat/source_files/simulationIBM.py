# -*- coding:Utf-8 -*-
'Simulation of the growth-fragmentation-death chemostat IBM'
import numpy as np
import random as rd
import time
import os
import shutil
import os
import sys

def simulation(folderName):
    'run of the IBMs'
    sys.path.append(os.getcwd()+'/'+ folderName +'/source_files')
    import simulationParameters as parameters
    
    #copy of the Python files    
    shutil.copy("source_files/simulationIBM.py", folderName+'/source_files')
    shutil.copy("source_files/class_universe.py", folderName+'/source_files')
    shutil.copy("source_files/plot_parameters.py", folderName+'/source_files')
    shutil.copy("source_files/class_individual.py", folderName+'/source_files')
    shutil.copy("source_files/class_population.py", folderName+'/source_files')
    shutil.copy("source_files/class_efficiency.py", folderName+'/source_files')
    
    sys.path.append(os.getcwd()+'/'+folderName+'/source_files')
    import class_universe as universe
    import plot_parameters
    
    #plot of the parameter functions
    plot_parameters.plot_curve_of_the_division_rate(folderName)
    plot_parameters.plot_curve_of_the_growth_speed(folderName)
    plot_parameters.plot_curve_of_the_division_kernel(folderName)
    
    #Initialization of the random number generator
    rd.seed(0)
    np.random.seed(0)
    os.mkdir(folderName+'/IBM')
    for k in xrange(parameters.Nbsimu):
        #Creation of a folder to save data of the k-th simulation 
        os.mkdir(folderName+'/IBM/Simulation{0}'.format(k))
        sys.stdout.write("\rSimulation {0} / {1}".format(k+1,
                                                         parameters.Nbsimu))
        sys.stdout.flush()
            
        #Initialization of the chemostat
        chemostat = universe.Chemostat()
        
        #Gillespie Algorithm
        chemostat.gillespie(parameters.T,
                            parameters.save_step_time,
                            parameters.eulerTime,
                            folderName+'/IBM/Simulation{0}'.format(k))
        np.save(folderName+'/IBM/Simulation{0}/seed.npy'.format(k),
                rd.getstate())
        np.save(folderName+'/IBM/seed.npy'.format(k), rd.getstate())
    print ''

