# -*- coding: utf-8 -*-
class Efficiency(object):
    '''The object describes the numbers of acceptances and rejections and the
        proportion of acceptance. This class will be used to determine the
        efficiency of the algorithm used to simulate the IBM or the BDP.'''
    def __init__(self):
        '''definition of an efficiency describes by numbers of acceptances and
           rejections initialized with 0 and the proportion of acceptance
           initialized with 1.'''
        self.__acceptance = 0
        self.__rejection = 0
        self.__acceptanceRate = 1.0
    
    def getAcceptanceRate(self):
        'return the proportion of acceptance'
        return self.__acceptanceRate
    
    def acceptance(self):
        'modify the object in case of an additional acceptance'
        self.__acceptance += 1
        self.__acceptanceRate = self.__acceptance/(self.__acceptance
                                                   +self.__rejection)
    
    def rejection(self):
        'modify the object in case of an additional rejection'
        self.__rejection += 1
        self.__acceptanceRate = self.__acceptance/(self.__acceptance
                                                   +self.__rejection)
