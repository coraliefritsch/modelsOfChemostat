# -*- coding:Utf-8 -*-
import numpy as np
import pylab as pl
import os
import sys
import scipy.stats
import leastsqbound as lsqb
import shutil

size_of_label = 22    #font size of labels
size_of_ticks = 18    #font size of ticks

def law_of_a_birth_death_process(x, D, lambdaa, N0):
    """
return the density of the law of a birth death process with N0 initial 
individuals birth rate lambdaa and death rate D"""
    a = (N0*D*(lambdaa-D)**2*np.exp((lambdaa-D)*x)/
         ((lambdaa*np.exp((lambdaa-D)*x)-D)**2))
    return (a* ((D*np.exp((lambdaa-D)*x)-D)/
                (lambdaa*np.exp((lambdaa-D)*x)-D))**(N0-1))

def fct_MC(lambdaa, x, kernel, D, N0):
    """
return the eulerian distance beetween kernel and the law of a birth death
process with N0 initial individuals, birth rate lambdaa and death rate D"""
    return np.sqrt((kernel-law_of_a_birth_death_process(x, D, lambdaa, N0))**2)

def plot_the_law(folder):
    """
Plot the density of the law of the extinction time of 
    - the IBM simulation in the folder
    - the birth death process with constant rates which is closer to the law
of extinction time of IBM, calculated by a least squares method.
The plot is saved in the extinction_time.pdf file"""

    sys.path.append(os.getcwd()+'/'+folder+'/source_files')
    import simulationParameters
    
    #Save the python file
    if os.path.exists(folder+'/source_files')==False:           
        os.mkdir(folder+'/source_files')   
    shutil.copy("source_files/law_of_extinction_time.py",
                folder+'/source_files')

    nbsimu = simulationParameters.Nbsimu
    D = np.float(simulationParameters.D)
    N0 = np.float(simulationParameters.n0)

    #for each simulations, the extinction time is saved in IBMextinctionTime
    IBMextinctionTime = np.zeros(nbsimu)  #memory allocation
    nbNonExtinction = 0
    for i in range(nbsimu):
        filepath = folder+'/IBM/Simulation{0}/extinction_time.npy'.format(i)
        if os.path.exists(filepath)==False:
            print "The IBM population ", i , "is not extincted"
            nbNonExtinction += 1            
        else:
            IBMextinctionTime[i]=np.load(filepath)
    
    if nbNonExtinction==nbsimu :
        #No extinction
        print ("No population of the simulation " + folder + 
               ' is extincted. ' +
               'The law of the extinction time can not be calculated')
    if nbNonExtinction==nbsimu-1:
        #Only 1 extinction
        tps = IBMextinctionTime[IBMextinctionTime>0][0]
        print "Only one population is extincted." 
        print "The extinction was at time t=",tps
    if nbNonExtinction<nbsimu-1:
        #More than 2 extinctions : we plot the law
        IBMkernel = scipy.stats.gaussian_kde(
                                        IBMextinctionTime[IBMextinctionTime>0])
    
        tps_ext_max = np.max(IBMextinctionTime)
        tps_ext_min = np.min(IBMextinctionTime)
        h = (tps_ext_max-tps_ext_min)/100.0
            
        x = np.arange(np.max([h,tps_ext_min-(tps_ext_max-tps_ext_min)/2]),
                          tps_ext_max+(tps_ext_max-tps_ext_min)/2, h)
            
        mode = x[IBMkernel(x)==np.max(IBMkernel(x))][0]
        esp = np.sum(x*IBMkernel(x))*h
        mu = (np.log(mode)+2*np.log(esp))/3
            
        alpha = (esp+mode)/(esp-mode)
        beta = (alpha+1)*mode

        lambda_opt=lsqb.leastsqbound(fct_MC, 0, args=(x, IBMkernel(x), D, N0),
                                       bounds=[(0, D)])[0]

        BDPlaw = False
        if os.path.exists(folder +'/BDP'):
            stop = False
            while stop==False:
                bdp = raw_input("Do you also want the extinction law of the birth-death process (y,n)? ")
                if bdp=='y' or bdp=='Y':
                    BDPlaw = True
                    stop = True
                if bdp=='n' or bdp=='N':
                    stop = True
                
        #Birth-Death Process
        if BDPlaw:
            nbsimuPNM = 0
            stop = False
            while stop==False:
                if os.path.exists(folder+
                                  '/BDP/Simulation{0}'.format(nbsimuPNM)):
                    nbsimuPNM += 1
                else:
                    stop = True

            BDPextinctionTime = np.zeros(nbsimuPNM)
            for i in range(nbsimuPNM):
                if os.path.exists(folder+
                    '/BDP/Simulation{0}/extinction_time.npy'.format(i))==False:
                    print "The BDP population ", i , "is not extincted"
                else:
                    BDPextinctionTime[i]=np.load(folder+
                            '/BDP/Simulation{0}/extinction_time.npy'.format(i))
            BDPkernel = scipy.stats.gaussian_kde(
                                       BDPextinctionTime[BDPextinctionTime>0]) 

        pl.plot(x, IBMkernel(x), color='r', linewidth=2, label='IBM')
        if BDPlaw:
            pl.plot(x, BDPkernel(x), 'b--', linewidth=2, label='BDP')

        #'extinction law of the homogeneous BDP which fit the best the IBM'
        #pl.plot(x, law_of_a_birth_death_process(x, D,lambda_opt, N0),
        #        color = 'c', label=str(lambda_opt))
        pl.xlabel('time (h)', fontsize=size_of_label)  
        pl.ylabel("density", fontsize=size_of_label)
        pl.legend()
        pl.tick_params(axis='both', labelsize=size_of_ticks)
        pl.savefig(folder + '/extinction_time.pdf', dpi=100)
        print "the law of the extinction_time is plotted in ",
        print folder + '/extinction_time.pdf'
