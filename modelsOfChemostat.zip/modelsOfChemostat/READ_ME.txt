modelsOfChemostat

(C) Coralie Fritsch and Fabien Campillo
    Coralie.Fritsch@inria.fr  Fabien.Campillo@inria.fr
    Version 1.0 - November 29, 2016
    This software is governed by the CeCILL license

This software simulate four chemostat models (see the model descriptions below)

Input : 
- the Python file global_parameters.py for simulation with new parameters;
- the Python file Simulations/#simulationName/source_file/simulationParameters.py for
simulation with parameters of the folder #simulationName.

Output:
- realizations of the models are saved in files .npy in the folder Simulations/#simulationName/
- graphs of the models are saved in the folder Simulations/#simulationName/

===============================================================================
STRUCTURE OF THE CURRENT DIRECTORY

The current directory (at initialization) contains:

   READ_ME.txt	       	       this file
   global_parameters.py	       parameters file
   run.py		       main python script 
   source_files/	       source files 

-------------------------------------------------------------------------------
To run simulations :
- check the Python version of your computer, then, 
- in a terminal, go in the folder "modelsOfChemostat",
- run the script run.py in the terminal using the Python call
  associated to your computer version
  	     eg : python run.py	or	python2.7 run.py

The script run allows to realize simulations with news parameters
(which are to be enter in the global_parameters files) or to realize
additional actions for an old set of parameters.

The main possible actions are the simulations of :
  1) the Individual-Based growth-fragmentation-death
     chemostat Model (IBM) (additional runs can be add to already
     performed IBM simulations)
  2) the growth-fragmentation-death deterministic PDE model
  3) Simulation of a Crump-Young model where the parameters of the
     birth rate are Monod parameters fitted on the IBM simulations 
then, the following actions are possible: 
  - Computation of the empirical law of the time of extinction the 
    IBM and/or Crump-Young model(s)
  - Realization of graphs of performed simulations
  - Graph of ODE model(s) with Monod kinetics  

===============================================================================
DESCRIPTION OF THE MODELS

1) GROWTH-FRAGMENTATION-DEATH CHEMOSTAT INDIVIDUAL BASED MODEL

The growth-fragmentation-death chemostat IBM is defined by the following
mechanisms:
Each individual with mass x
- dived at rate divisionRate(x) into two individuals with masses
  alpha*x and (1-alpha)*x where alpha*x is distributed according to
  divisionKernel(x)
- is removed from the chemostat at rate D, where D is the dilution
  rate of the chemostat
- grows at speed mu(S)*g(x) where S is the substrate concentration of
  the chemostat, which is given by the following equation
       d/dt S_t = D*(S_in-S_t) - k/V * mu(S)*sum(g(X))
  where
	S_in is the input substrate concentration in the chemostat,
 	V is the volume of the chemostat,
	k is a stoichiometric coefficient
	X = [x1,...,xn] is the vecteur of the n individuals with
	masses x1,...,xn in the chemostat at time t.

2) GROWTH-FRAGMENTATION-DEATH CHEMOSTAT PDE MODEL

The growth-fragmentation-death chemostat PDE model is given y the
following system of integro-differential equation

    d/dt p_t(x) = -mu(S_t)*d/dx g(x) - (b(x)+D)*p_t(x)+
                   2*integral b(z)*divisionkernel(x/z)/z p_t(z)

and

    d/dt S_t = D*(S_in-S_t) - k/V * mu(S)*integral(g(x)*p_t(x))

where the integrates are on the domain [0,M] where M is the maximale
mass of an individual. p_t represents the mass density at time t.

3) CRUMP-YOUNG MODEL

The Crump-Young model is defined by the following mechanisms:
each individual 
- gives birth to another one at rate mu(S_t) where S_t follows the
  following equation:
	d/dt S_t = D*(S_in-S_t)-k/V*mu(S_t)*N_t*m
  where N_t is the number of individuals at time t and m is the mean
  mass of individuals
- is removed from the chemostat at rate D

4) ODE MODEL [simulated only for graphical purpose]

The ODE model is given by the following system of equation:
    d/dt X_t = (mu(S)-D)*X_t
    d/dt S_t = D*(S_in-S_t) - k/V * mu(S)*X_t
where X_t is the biomass concentration at time t.
In the simulation, Monod kinetic are considered that is mu is defined by
   mu(S)= mumax*S/(Ks+S)
where mumax is the maximal growth rate et Ks is the half-velocity constant.


REFERENCES

[1] Coralie Fritsch. Approches probabilistes et numériques de modèles 
    individus-centrés du  chemostat. Thèse Université de Montpellier 2, 2014.
    https://tel.archives-ouvertes.fr/tel-01099048v1
[2] Fabien Campillo and Fritsch, Coralie. Weak Convergence of a 
    Mass-Structured Individual-Based Model. Applied Mathematics & Optimization, 
    72(1): 37-73, 2015
    http://link.springer.com/article/10.1007%2Fs00245-014-9271-3
    Erratum Same issue, 72: 75.
    http://link.springer.com/article/10.1007/s00245-015-9294-4
[3] Coralie Fritsch, Jérôme Harmand and Fabien Campillo. A modeling approach 
    of the chemostat. Ecological Modelling, 299: 1-13, 2015.
    http://www.sciencedirect.com/science/article/pii/S0304380014005948

