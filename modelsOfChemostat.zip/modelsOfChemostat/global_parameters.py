# -*- coding: utf-8 -*-
'This file contains the simulation parameters'
import numpy as np
import random

'''============================================================================
                         Simulation parameters :
============================================================================'''
T = 30                        #End time of the simulation
save_step_time = 0.1          #Step time for the save of data
Nbsimu = 15                   #Number of IBM simulations

'''============================================================================
                         Chemostat parameters :
============================================================================'''
V = 0.2                       #Volume 
D = 0.4                      #Dilution Rate
S_in = 10                     #Input substrate concentration 
S_0 = 5                       #Initial substrate concentration

'''============================================================================
     Interaction parameters between the substrate and the population :
============================================================================'''
k = 1                          #Stoichiometric coefficient
Ks = 10                        #Monod half-velocity constant
mumax = 1.0

#the growth of one individual with mass x is of the form mu(S)*g(x) where S is
#the substrate concentration			
def mu(s):
    return mumax * s / (Ks+s)  #Monod cinetic

def g(x):
    y = np.zeros(np.size(x))
    y[x>0]=np.log(M/x[x>0])*x[x>0]
    return y

def diff_of_g(x):
    'derivative of g'
    y = np.zeros(np.size(x))
    y[x>0] = np.log(M/x[x>0]) -1
    return y

'''============================================================================
                         Population parameters :
============================================================================'''
n0 = 10                        #Number of individual at the initial time
M = 0.001                      #Maximal mass of individuals
max_div_rate = 1               #Maximal division rate

def initialDensity(x):
    'Initial distribution of individuals'
    return (((((x-0.0005)/0.00025)*(1-(x-0.0005)/0.00025))**5)
		  		*(x>0.0005)*(x<0.00075))

'Division rate function : '
xmin = 0.0004                  #minimal mass for division
def divisionRate(x):
    '''return the division rate of individual(s) with mass(es) x : a value if x
    is a reel and an array of division rate of values of x if x is an array'''
    return max_div_rate * (x>xmin)

'Division kernel function : '
beta = 10
def divisionKernel(x):
    'return the division kernel of individual(s) with mass(es) x'
    y = x*1
    y[y>=1] = 0
    h = 0.0001
    z = np.arange(h,1+h/2,h)
    K = h*np.sum((z*(1-z))**(beta-1))    
    return 1/K*(y*(1-y))**(beta-1)   #beta law B(beta,beta)

def masse_after_division(x):
    'simulate the mass of a daughter bacteria, in case of division'
    return x*random.betavariate(beta,beta)

'''============================================================================
                          Discretisation parameters :
============================================================================'''
massStep = M*0.0005             #Mass discretisation step for IDE resolution
eulerTime = 0.00125      #Time discretisation step for IDE resolution
